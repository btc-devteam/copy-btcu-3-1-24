import SearchComponent from "@/components/header/SearchComponent";




export default function Search() {
  return (

<div >
       
    {/* <SearchComponent /> */}
      </div>
 
  );
}


