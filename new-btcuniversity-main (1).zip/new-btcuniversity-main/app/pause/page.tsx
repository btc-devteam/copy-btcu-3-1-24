

export default function Pause() {
  return (
    <main className="">
<div className="">
      placeholder for the Pause page
      </div>
      
    </main>
  )
}

