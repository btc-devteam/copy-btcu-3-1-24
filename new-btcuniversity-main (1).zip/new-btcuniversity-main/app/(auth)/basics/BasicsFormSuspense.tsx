import { FC, HTMLAttributes } from "react";
// Utils
import { cn } from "@/utils/shadcn";
// Lib
import { getUserAddress } from "@/features/login/userHandler";
// Types
import { Address, UserSession } from "@/interfaces";
import { IUserProfile } from "@/features/wp/user";
// Components
import BasicInfoForm from "@/components/auth/BasicInfoForm";

interface IProps extends HTMLAttributes<HTMLDivElement> {
  user: UserSession;
  refreshedToken?: string;
  type?: "page" | "modal";
  userAdditionalData?: IUserProfile;
  searchParams?: { [key: string]: string | string[] | undefined };
}

export const getUserInfo = async (session: UserSession) => {
  const res = await getUserAddress(session, {
    idType: "DATABASE_ID",
  });

  return res;
};

const BasicsFormSuspense: FC<IProps> = async ({
  className,
  refreshedToken,
  user,
  type = "page",
  userAdditionalData,
  searchParams,
  ...props
}) => {
  // Replace user token with the fresh token
  if (refreshedToken) {
    user.authToken = refreshedToken;
  }
  let userAddress = await getUserInfo(user);

  if (typeof userAddress === "string") {
    throw new Error("Somthing went wrong!");
  }
  const searchVal = searchParams?.q;
  return (
    <div className={cn("", className)} {...props}>
      <h2 className="text-24 text-themecolor-500 font-semibold my-6">
        Update My Info
      </h2>
      <BasicInfoForm
        user={user}
        type={type}
        addressData={{
          ...userAddress,
          phone: userAdditionalData?.user?.phone ?? userAddress.phone,
          firstName:
            userAdditionalData?.user.firstName ?? userAddress.firstName,
          lastName: userAdditionalData?.user.lastName ?? userAddress.lastName,
        }}
      />
    </div>
  )
};

export default BasicsFormSuspense;
