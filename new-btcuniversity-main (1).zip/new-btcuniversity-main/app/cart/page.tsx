import Cart from "@/components/cart/Cart"

const cart = () => {
  return (
    <main className="wrapper">
      <Cart />
    </main>
  )
}

export default cart

