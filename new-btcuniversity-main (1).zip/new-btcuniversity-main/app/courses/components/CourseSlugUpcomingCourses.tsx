import React, { HTMLAttributes } from 'react';
import { getUpcomingCourses } from '../helper';
import Upcoming from '@/components/Upcoming';

interface CourseSlugUpcomingCoursesIncludedProps extends HTMLAttributes<HTMLDivElement> {
    themeColor: string;
    userDataBaseId: string;
}

const CourseSlugUpcomingCourses: React.FC<CourseSlugUpcomingCoursesIncludedProps> = async ({ themeColor, className, userDataBaseId }) => {

    const upcomingCoursesProm = getUpcomingCourses();
    const upcomingCourses = await upcomingCoursesProm;
    const upcomingCoursesChecked = upcomingCourses ? upcomingCourses : [];

    return (
        <div className={className}>
            {upcomingCoursesChecked.length > 0 && (

                <Upcoming
                    userDataBaseId={userDataBaseId}
                    upcomingCourses={upcomingCoursesChecked}
                    themeColor={themeColor}
                />

            )}
        </div>
    );
}

export default CourseSlugUpcomingCourses;