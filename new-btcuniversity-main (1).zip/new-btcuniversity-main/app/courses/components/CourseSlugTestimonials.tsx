import React, { HTMLAttributes } from 'react';
import { extractCourseAll, extractCourseTestimonials, getCourseAll } from '../helper';
import Testimonials from '@/components/Testimonials';
import { UserSession } from '@/interfaces';

interface CourseSlugTestimonialsProps extends HTMLAttributes<HTMLDivElement> {
    params: { slug: string };
    user: UserSession | null;
}

const CourseSlugTestimonials: React.FC<CourseSlugTestimonialsProps> = async ({ params, className, user }) => {

    // const courseTestimonialsProm = getCourseTestimonials(params);
    // const courseTestimonials = await courseTestimonialsProm;
    // const { courseTestimonialsNew } = extractCourseTestimonials(courseTestimonials);

    const courseAllProm = getCourseAll(params);
    const courseAll = await courseAllProm;
    const { courseTestimonialsNew, courseID } = extractCourseAll(courseAll)


    return (
        <div className={className}>
            <Testimonials testimonials={courseTestimonialsNew} userDataBaseId={(user?.userDataId || 0).toString()} courseId={courseID} />
        </div>
    );
}

export default CourseSlugTestimonials;