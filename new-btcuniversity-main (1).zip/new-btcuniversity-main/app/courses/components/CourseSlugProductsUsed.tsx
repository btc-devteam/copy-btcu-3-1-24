import React, { HTMLAttributes } from 'react';
import { extractCourseAll, extractCourseProductsUsed, getCourseAll, getCourseProductsUsed } from '../helper';
import ProductsUsed from '@/components/ProductsUsed';
import { UserSession } from '@/interfaces';

interface CourseSlugProductsUsedProps extends HTMLAttributes<HTMLDivElement> {
    params: { slug: string };
    user: UserSession | null;
}
const themecolor = '#523D34'
const CourseSlugProductsUsed: React.FC<CourseSlugProductsUsedProps> = async ({ params, className, user }) => {

    // const courseProductsUsedProm = getCourseProductsUsed(params);
    // const courseProductsUsed = await courseProductsUsedProm;
    // const { usedProducts } = extractCourseProductsUsed(courseProductsUsed);

    const courseAllProm = getCourseAll(params);
    const courseAll = await courseAllProm;
    const { usedProducts, courseID } = extractCourseAll(courseAll)

    return (
        <div className={className}>
            {usedProducts.length > 0 && (
                <div>

                    <ProductsUsed productsUsed={usedProducts} productTitleTextColor={themecolor} userDataId={(user?.userDataId || 0).toString()} courseId={courseID} />
              
                </div>
            )}
        </div>
    );
}

export default CourseSlugProductsUsed;