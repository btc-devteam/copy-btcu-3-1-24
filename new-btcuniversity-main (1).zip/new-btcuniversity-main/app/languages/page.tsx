import Herotext from "@/components/text/Hero";
import { getRequestCookie } from "@/components/auth/getAuthCookie";
import { cookies } from "next/headers";
import { Suspense } from "react";
import { Skeleton } from "@/components/ui/Skeleton";
import LanguagesCategoryHero from "./components/LanguagesCategoryHero";
import NewLanguagesCourses from "./components/NewLanguagesCourses";
import LanguagesTips from "./components/LanguagesTips";
import AllLanguagesCourses from "./components/AllLanguagesCourses";
import LanguagesEducators from "./components/LanguagesEducators";
import LanguagesSpotlight from "./components/LanguagesSpotlight";
import LanguagesSubCallout from "./components/LanguagesSubCallOut";
import H3Text from "@/components/text/H3Text";
import ExploreMoreCategories from "@/components/ExploreMoreCategories";


export const metadata = {
  title: 'LANGUAGES',
  description: 'BTC University offers subtitles in 6 languages! English, Spanish, Italian, French, Portuguese & Russian.',
}

export default async function LanguagesPage() {

  const heroTitle = "Languages";

  // User Data
  // fetch user cookie
  const userProm = getRequestCookie(cookies());

  // Fetching data in parallel
  const user = await userProm;

  return (
    <main >
      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <LanguagesCategoryHero
        />
      </Suspense>
      {/* <div className="flex container">
        <H3Text text={heroTitle}  />
      </div> */}
      <div >

      

        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>}>
          <NewLanguagesCourses user={user} heroTitle={heroTitle}
          />
        </Suspense>

        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>}>
          <LanguagesTips
            user={user}
            heroTitle={heroTitle}
          />
        </Suspense>

        {/* <Section title="All Haircuts" cards={allCutCards} /> */}

        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>}>
          <AllLanguagesCourses
          />
        </Suspense>

    

        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>}>
          <LanguagesEducators
          />
        </Suspense>

   

  

        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>}>
          <LanguagesSpotlight
          />
        </Suspense>



        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>}>
          <LanguagesSubCallout user={user}
          />
        </Suspense>
        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>}>
          <ExploreMoreCategories activeCategory="" />
        </Suspense>
      </div>
    </main>
  );
}