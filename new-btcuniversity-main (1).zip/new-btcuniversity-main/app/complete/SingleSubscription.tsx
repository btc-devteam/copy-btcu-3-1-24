"use client";
import { FC, HTMLAttributes, useEffect } from 'react'
// Utils
import { cn } from '@/utils/shadcn'
import { PurchaseTypes } from './page'
//  Components
import SH1Text from '@/components/text/SH1Text'
import ParagraphText from '@/components/text/Paragraph'
import Link from 'next/link'
import WelcomeComponent from '@/components/WelcomeComponent'
import { UserSession } from '@/interfaces'
import { getCurrentUserDataPurchasedSubscriptions } from '../helper';
import { useSearchParams } from 'next/navigation';

interface IProps extends HTMLAttributes<HTMLDivElement> {
    user: UserSession;
    type: PurchaseTypes
    customerEmail: string;
    customerName: string;
    userEmail: string;
    userPhone: string;
    userFirstName: string;
    userLastName: string;
    userStreet: string;
}

const SingleSubscription: FC<IProps> = ({ user, customerName, customerEmail, className, type,
    userEmail,
    userPhone,
    userFirstName,
    userLastName,
    userStreet,
     ...props }) => {
    
    const searchParams = useSearchParams();

    const stripeSubscriptionId = searchParams?.get("stripeSubscriptionId");
    const finalValue = searchParams?.get("subscriptionFinalValue");

    useEffect(() => {
      // Using type assertion to tell TypeScript that window has a property dataLayer
      (window as any).dataLayer = (window as any).dataLayer || [];
      if (stripeSubscriptionId === null) {
        (window as any).dataLayer.push({
          event: "purchase",
    
          itemName: "free_account_signup",
          userDataId: user?.userDataId,
          userEmail: userEmail,
          userPhone: userPhone,
          userFirstName: userFirstName,
          userLastName: userLastName,
          userStreet: userStreet,
  
          purchaseType: type,
          stripeSubscriptionId: stripeSubscriptionId,
          // You can add any other relevant data here
  
          finalValue: Number(finalValue),
          currency: "USD",
  
        });
      }
      else {
        (window as any).dataLayer.push({
          event: "purchase",
    
          itemName: "subscription",
          userDataId: user?.userDataId,
          userEmail: userEmail,
          userPhone: userPhone,
          userFirstName: userFirstName,
          userLastName: userLastName,
          userStreet: userStreet,
  
          purchaseType: type,
          stripeSubscriptionId: stripeSubscriptionId,
          // You can add any other relevant data here
  
          finalValue: Number(finalValue),
          currency: "USD",
  
        });
      }
    }, [user, type, stripeSubscriptionId]); // Dependencies array ensures this effect runs only when these props change

    if (type !== "single-subscription") {
        return <></>
    }
    return (
        <div id={(stripeSubscriptionId === null) ? "Single-Free-Subscription-Div" : "Single-Paid-Subscription-Div"} className={cn("", className)} {...props}>
            <WelcomeComponent email={customerEmail} customerName={customerName} />
        </div>
    )
}

export default SingleSubscription


// this should show once someone completed a purchse for a subscription that auto renews. monthly, 6 month, yearly. NOT FREE   