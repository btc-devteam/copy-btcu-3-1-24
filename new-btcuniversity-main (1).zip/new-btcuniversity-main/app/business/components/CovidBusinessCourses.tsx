// import React from 'react';
// import { getCovidBusinessCourses, createCourseCards, Section } from '../helper';

// const CovidBusinessCourses: React.FC = async () => {

//     const covidBUSNCoursesPromise = getCovidBusinessCourses();
//     const covidBUSNCourses = await covidBUSNCoursesPromise;
//     const businessCovidSupportCards = createCourseCards(covidBUSNCourses);

//     return (
//         <div id="Covid-section">
//           <Section title="COVID Support" cards={businessCovidSupportCards} />
//         </div>
//     );
// }

// export default CovidBusinessCourses;