import ExploreMoreCategories from "@/components/ExploreMoreCategories";
import Herotext from "@/components/text/Hero";
import { getRequestCookie } from "@/components/auth/getAuthCookie";
import { cookies } from "next/headers";
import { Suspense } from "react";
import { Skeleton } from "@/components/ui/Skeleton";
import BusinessTips from "./components/BusinessTips";
import TipsSubCallout from "./components/TipsSubCallout";
import EventsTips from "./components/EventsTips";
import ExtensionTips from "./components/ExtensionTips";
import HaircolorTips from "./components/HaircolorTips";
import HaircuttingTips from "./components/HaircuttingTips";
import LanguagesTips from "./components/LanguagesTips";
import MensTips from "./components/MensTips";
import StylingTips from "./components/StylingTips";
import TextureTips from "./components/TextureTips";
import TipsCategoryHero from "./components/TipsCategoryHero";
import H1Text from "@/components/text/H1Text";

export const metadata = {
  title: 'Quick Hair Tips & Tricks',
  description: 'Our Quick Tips videos offer bite-sized wisdom to elevate your techniques and business strategy. Perfect for busy stylists looking to learn on the go.',

}
// TO DO: description field above, see comment in haircutting/page.tsx -- This should be dinamically pulled from every category page
// or entered here until launch

export default async function Tips() {

  // const heroTitle = "Tips";

  // Get user cookie
  const userProm = getRequestCookie(cookies());

  // Fetching all data in parallel
  const user = await userProm;


  return (
    <main >
      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <TipsCategoryHero />
        
      </Suspense>
      <div className="flex container">
        <H1Text text={"Quick Tips"} />
      </div>
      <div className='space-between-categories' />
      {/* <div className="flex slider-container items-center pt-2 pb-3 ">
        <div className="h-full">
          <ChevronRight size={18} />
        </div>        <div className="flex overflow-x-auto ">
          <SpecialtiesButton
            text="Series: Social Media for Hairdressers" scrollToId={"Series-section"}
            number="4" />
          <SpecialtiesButton
            text="Social Media" scrollToId={"Social-section"}
            number="4" />

          <SpecialtiesButton
            text="Recession"
            scrollToId={"Recession-section"}
            number="4"
          />


          <SpecialtiesButton
            text="Management & Culture " scrollToId={"Management-section"}
            number="4" />

          <SpecialtiesButton
            text="Consultations" scrollToId={"Consultations-section"}
            number="4" />
          <SpecialtiesButton
            text="Interviews" scrollToId={"Interviews-section"}
            number="4" />
          <SpecialtiesButton
            text="Social Climbing" scrollToId={"social-climbing-section"}
            number="4" />
          <SpecialtiesButton
            text="Social Media Photography" scrollToId={"social-photography-section"}
            number="4" />



        </div>

      </div> */}


      <Suspense fallback={<div className="w-full flex flex-col gap-y-0">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <BusinessTips user={user} heroTitle={"Business"} />
      </Suspense>


      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <HaircolorTips user={user} heroTitle={"Hair Color"} />
      </Suspense>


   
    

     

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <HaircuttingTips user={user} heroTitle={"Haircutting"} />
      </Suspense>

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <StylingTips user={user} heroTitle={"Styling"} />
      </Suspense>

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <TextureTips user={user} heroTitle={"Texture"} />
      </Suspense>

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <ExtensionTips user={user} heroTitle={"Extensions"} />
      </Suspense>

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <MensTips user={user} heroTitle={"Men's"} />
      </Suspense>

      


  

 

      <Suspense fallback={<div className="w-full flex flex-col gap-y-0">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <EventsTips user={user} heroTitle={"BTC Events"} />
      </Suspense>

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <LanguagesTips user={user} heroTitle={"Languages"} />
      </Suspense>
      

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <TipsSubCallout user={user} />
      </Suspense>

      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
        <Skeleton className="h-14" />
      </div>}>
        <ExploreMoreCategories activeCategory="" />
      </Suspense>

    </main >

  );
}