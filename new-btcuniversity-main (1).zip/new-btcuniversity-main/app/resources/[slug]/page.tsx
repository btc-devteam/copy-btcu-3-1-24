import { getRequestCookie } from "@/components/auth/getAuthCookie";
import { cookies } from "next/headers";
import Skeleton from "@mui/material/Skeleton";
import { Suspense } from "react";
import DownloadableHero from "../components/DownloadableHero";
import SuggestedDownloads from "../components/SuggestedDownloads";
import H3Text from "@/components/text/H3Text";

export default async function ResourceSlugPage({
  params,
}: {
  params: { slug: string };
}) {
  // User Data
  // fetch user cookie
  const userProm = getRequestCookie(cookies());

  // Fetching data in parallel
  const user = await userProm;

  // Checking if we have received course data
  if (!params) {
    return (
      <main>
        <div>Loading...</div>
      </main>
    );
  }
  return (
    <main className="md:container md:mx-auto">
   
          {/* Left Column - Container 1 */}

          <div className="">
          
           
           
            <Suspense
              fallback={
                <div className="w-full flex flex-col gap-y-6 order-1 ">
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                </div>
              }
            >
              <DownloadableHero
                params={params}
                user={user}
              />
          </Suspense>
       
        
        <div className='space-between-categories' />

            <Suspense
              fallback={
                <div className="w-full flex flex-col gap-y-6 order-1 ">
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                </div>
              }
            >
          <div className="slider-container md:pl-0 ">
            <H3Text text="Suggested Downloads" />
            <div className="space-under-category-titles" />

                <SuggestedDownloads
                  params={params}
                />
              </div>
            
            </Suspense>
        
            {/* <Suspense
              fallback={
                <div className="w-full flex flex-col gap-y-6 order-1 ">
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                </div>
              }
            >
              <DownloadYouWillLearn
                params={params}
              />
            </Suspense> */}


            <div className="med-space" />
          </div>
          {/* Right Column - Container 2 */}
          {/* <div className="container md:pt-[32px] place-items-end items-center w-full  lg:w-4/12 min-w-[370px] mr-auto lg:pl-[24px] ">
            <H3Text text="Suggested Downloads" />
            <div className="space-under-category-titles" />

            <Suspense
              fallback={
                <div className="w-full flex flex-col gap-y-6 order-1 ">
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                  <Skeleton className="h-14" />
                </div>
              }
            >
              <SuggestedDownloads
                params={params}
              />
            </Suspense>
          </div> */}
 
    
    </main>
  );
}
