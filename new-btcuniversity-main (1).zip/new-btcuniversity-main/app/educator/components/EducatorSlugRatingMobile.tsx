import React from 'react';
import { Rating } from "@mui/material";

interface EducatorSlugRatingMobileProps {
    params: { slug: string };
    themeColor: string;
}

const EducatorSlugRatingMobile: React.FC<EducatorSlugRatingMobileProps> = async ({ params, themeColor }) => {

    // const educatorAllProm = getEducatorAll(params);
    // const educatorAll = await educatorAllProm;
    // const { educatorAverageRating, educatorNoOfTestimonials } = extractEducatorAll(educatorAll)
    // TO DO AFTER LAUNCH Mihai/Hamzah: add educatorAverageRating and educatorNoOfTestimonials php functions, then fetch them via the GET_EDUCATOR_BY_SLUG_FOR_EDU_SLUG_PAGE query

    return (
        <div className="flex ">
            <div className="flex items-center py-2">
                <Rating name="half-rating-read" defaultValue={5} precision={0.5} readOnly style={{ color: themeColor }} />
                {/* <div className="px-2 flex"> */}
                { }
                    {/* <ParagraphText text={totalNoOfTestimonials.toString()} className="text-themeColor" /> */}
                {/* above line was commented out even before */}
                    {/* <ParagraphText text={'?'} className="text-themeColor" /> */}

                    {/* <ParagraphText text=")" className="text-themeColor" /> */}
                {/* </div> */}
            </div>
        </div>
    );
}

export default EducatorSlugRatingMobile;