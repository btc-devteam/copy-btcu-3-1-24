import React from 'react';
import { getEducatorAll, extractEducatorAll, getCurrentUserDataEducatorSlugPage } from '../helper';
import { AccessedCourse, Course, Educator, UserSession } from '@/interfaces';
import CoursePageTitles from '@/components/text/CoursePageTitles';
import YouTubeVideoCard from '@/components/YouTubeVideoCard';
import H3Text from '@/components/text/H3Text';

interface EducatorSlugMyCoursesMobileProps {
    params: { slug: string };
    user: UserSession | null;
    themeColor: string;
}

const EducatorSlugMyCoursesMobile: React.FC<EducatorSlugMyCoursesMobileProps> = async ({ params, user, themeColor }) => {

    const educatorAllProm = getEducatorAll(params);
    const currentUserDataProm = getCurrentUserDataEducatorSlugPage(user?.userDataId || 0);
  
    const [educatorAll, currentUserData] = await Promise.all([educatorAllProm, currentUserDataProm])
  
    const { educatorCourses } = extractEducatorAll(educatorAll)

    const userWatchedCourses = currentUserData?.userDataMetadata?.accessedcourses || [];
  
    const userFinishedCourses = userWatchedCourses.filter((accessedCourse: AccessedCourse) => {
      return accessedCourse?.isCompleted === true;
    });
    const userFinishedCourseIDs = userFinishedCourses.map((accessedCourse: AccessedCourse) =>
      accessedCourse?.accessedcoursemetadata?.courseid || 0
    );
    // Checking if the educator courses are part of accessed courses and completed
    function checkIfCourseCompleted(courseID: number, userFinishedCourseIDs: number[]) {
      return userFinishedCourseIDs.some(databaseId => databaseId === courseID);
    }
  
    const createOnlineCourseCards = (courses: Course[]) => courses
      .map((course: Course) => (

        <YouTubeVideoCard key={course.slug} course={course} completed={checkIfCourseCompleted(course.databaseId, userFinishedCourseIDs)} 
        userDataBaseId={(user?.userDataId || 0).toString()}
        themeColor={themeColor} educators={(course?.courseMetadata?.educators || []).map((educator: Educator) => educator?.educatorMetaData?.instahandle || "")} />
  
      ));
  
    const onlineCoursesCards = createOnlineCourseCards(educatorCourses);
  

    return (
        <div className="px-[16px] bg-white">
            <div >
                <div className="flex ">
                    <div >

              <H3Text text='My Courses on BTCU' />
                        <div className="space-under-category-titles" />

                    </div>

                    <div className="px-2 flex">
              <H3Text text="(" /> <H3Text text={(educatorCourses.length).toString()} /> <H3Text text=")" />
                    </div>
                </div>
                <div >

                    {onlineCoursesCards}

                </div>
            </div>

            {/* <div className=" md:pl-0">
                <div className="flex md:pt-[64px]">


                  <SH1Text text="In-person Courses" />
                  <div className="px-2 flex">
                    <SH1Text text="(" /> <SH1Text text="3" /> <SH1Text text=")" />
                  </div>
                </div>
                <div >
                  <InPersonCourses inPersonPrice={inPersonPrice} inPersonCourseTitle={inPersonCourseTitle} inPersonCity={inPersonCity} inPersonImageSrc={inPersonImageSrc} inPersonLink={inPersonLink} inPersonDate={inPersonDate} inPersonState={inPersonState} themeColor={themeColor} />

                </div>
              </div> */}

        </div>
    );
}

export default EducatorSlugMyCoursesMobile;