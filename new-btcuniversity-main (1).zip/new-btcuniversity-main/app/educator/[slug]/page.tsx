import { getRequestCookie } from "@/components/auth/getAuthCookie";
import { cookies } from "next/headers";
import EducatorSlugMyCoursesDesktop from "../components/EducatorSlugMyCoursesDesktop";
import { Suspense } from "react";
import { Skeleton } from "@/components/ui/Skeleton";
import EducatorSlugLongBio from "../components/EducatorSlugLongBio";
import EducatorSlugShareButton from "../components/EducatorSlugShareButton";
import EducatorSlugPushPin from "../components/EducatorSlugPushPin";
import EducatorSlugInstaHandle from "../components/EducatorSlugInstaHandle";
import EducatorSlugName from "../components/EducatorSlugName";
import EducatorSlugRatingDesktop from "../components/EducatorSlugRatingDesktop";
import EducatorSlugHeadshot from "../components/EducatorSlugHeadshot";
import { Metadata, ResolvingMetadata } from "next/types";
import { getEducatorMetadata } from "../helper";
 

const themeColor = '#523D34';
// note: share url is in the sharebutton component

export default async function EducatorSlugPage({ params }: { params: { slug: string } }) {

  let imageWidth = 200;
  let imageHeight = 200;

  let screenWidth = typeof window !== 'undefined' ? window.innerWidth : 0;
  if (screenWidth < 768) {
    imageHeight = 200;
    imageWidth = 200;
  } else {
    imageHeight = 380;
    imageWidth = 380;
  }

  // User Data
  // fetch user cookie
  const userProm = getRequestCookie(cookies());

  // Fetching data in parallel
  const user = await userProm;

  return (
    <main className="mx-auto container">
      {/* Mobile */}
      {/* <div className="md:hidden">
        <div > */}
      {/* Left Column - Container 1 */}
      {/* <div >
            <div className="relative">
              <div className="absolute top-5 left-5 z-10">
              </div>

              <Suspense fallback={<div className="w-full flex flex-col gap-y-6 ">
                <Skeleton className="h-14" />
                <Skeleton className="h-14" />
                <Skeleton className="h-14" />
              </div>}>
                <EducatorSlugHeadshot
                  params={params} />
              </Suspense>

            </div>

            <div >
              <div className="container mt-[-100px] relative z-2  rounded-xl shadow-md p-4 bg-blend-bg-blend-difference">
                <div className="flex text-white text-3xl">
       
                </div>

       

                <div className="med-space" />
              </div>

              <div className="relative ">
                <div className="items-center bg-white md:bg-transparent  mt-[-35px] rounded-t-[24px] md:px-0">
                  <div className="space-under-category-titles" />
                  <div className="flex container">

                    <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                    </div>}>
                      <EducatorSlugRatingMobile
                        params={params}
                        themeColor={themeColor} />
                    </Suspense>


                    <div className='flex flex-grow justify-end items-center pt-3'>

                      <div className="pl-2 md:pl-0 flex items-center">

                        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                        </div>}>
                          <EducatorSlugPushPin params={params} user={user} />
                        </Suspense>
                      </div>

                      <div className=" md:pl-0  flex items-center">

                        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                        </div>}>
                          <EducatorSlugShareButton
                            params={params} />
                        </Suspense>
                      </div>

                    </div>
                  </div>

                  <div className="flex container">
                    <div>

                      <div className=" flex text-themeColor text-3xl">

                        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                        </div>}>
                          <EducatorSlugName
                            params={params} />
                        </Suspense>
                      </div>

                      <div className=" flex ">

                        <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                          <Skeleton className="h-14" />
                        </div>}>
                          <EducatorSlugInstaHandle
                            params={params} />
                        </Suspense>
                      </div>

                    </div>
                  </div>

                  <div className="container">

                    <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                    </div>}>
                      <EducatorSlugLongBio
                        params={params}
                        themeColor={themeColor} />
                    </Suspense>
                  </div>

                  {/* <div className="flex items-center pl-4 pt-4 md:pt-0 md:pl-2">

                    <BookTime
                      available={available}
                      educatorName={`${educatorData.educatorMetaData?.firstname || ""} ${educatorData.educatorMetaData?.lastname || ""}`}
                    />

                  </div> 
                </div>
              </div>
            </div>
          </div> 
     

          <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
          </div>}>
            <EducatorSlugMyCoursesMobile
              params={params}
              user={user}
              themeColor={themeColor} />
          </Suspense>


        </div>
      </div>

*/}

    

      {/* Desktop */}
      <div className="">
        <div className="md:flex md:mx-auto ">
          {/* Left Column - Container 1 */}
          <div className="items-center md:min-w-[370px] md:w-2/6 ">
            {/* <div className="min-w-[370px] max-w-[390px]"> */}

            <Suspense fallback={<div className="w-full ">
              <Skeleton className="h-14" />
              <Skeleton className="h-14" />
              <Skeleton className="h-14" />
            </div>}>
              <EducatorSlugHeadshot
                params={params} />
            </Suspense>

            <div >
              <div className="space-under-category-titles" />
              <div className="relative ">
                <div className="items-center flex">
                 

                  <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                    <Skeleton className="h-14" />
                    <Skeleton className="h-14" />
                    <Skeleton className="h-14" />
                  </div>}>
                    <EducatorSlugRatingDesktop
                      params={params}
                      themeColor={themeColor} />
                  </Suspense>

                  <div className="flex flex-grow justify-end">
                    <div className="pr-3">
                      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                        <Skeleton className="h-14" />
                        <Skeleton className="h-14" />
                        <Skeleton className="h-14" />
                      </div>}>
                        <EducatorSlugPushPin params={params} user={user} />
                      </Suspense>
                    </div>

                    <div className="px-3">
                      <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                        <Skeleton className="h-14" />
                        <Skeleton className="h-14" />
                        <Skeleton className="h-14" />
                      </div>}>
                        <EducatorSlugShareButton
                          params={params} />
                      </Suspense>
                    </div>
                  </div>

                  
                </div>
                <div>
                  <div className="flex ">
                    <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                    </div>}>
                      <EducatorSlugName
                        params={params} />
                    </Suspense>
                  </div>

                  <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                    <Skeleton className="h-14" />
                    <Skeleton className="h-14" />
                    <Skeleton className="h-14" />
                  </div>}>
                    <EducatorSlugInstaHandle
                      params={params} />
                  </Suspense>

                  <div className="space-under-category-titles" />


                  {/* <div className="flex items-center pl-4 pt-4 md:pt-0 md:pl-2">

                    <BookTime
                      available={available}
                      educatorName={`${educatorData.educatorMetaData?.firstname || ""} ${educatorData.educatorMetaData?.lastname || ""}`}
                    />

                  </div> */}
                </div>
              </div>
         
            </div>
        
            {/* </div> */}
          </div>

          {/* Right Column - Container 2 */}
          <div className="md:pl-[24px] ">
            {/* <div className='space-between-categories' /> */}

   

                <div className="">
                  <Suspense fallback={<div className="w-full flex flex-col gap-y-6">
                    <Skeleton className="h-14" />
                    <Skeleton className="h-14" />
                    <Skeleton className="h-14" />
                  </div>}>
                    <EducatorSlugLongBio
                      params={params}
                      themeColor={themeColor} />
                  </Suspense>

                </div>


                {/* <div className=" md:pl-0">
                <div className="flex md:pt-[64px]">


                  <SH1Text text="In-person Courses" />
                  <div className="px-2 flex">
                    <SH1Text text="(" /> <SH1Text text="3" /> <SH1Text text=")" />
                  </div>
                </div>
                <div >
                  <InPersonCourses inPersonPrice={inPersonPrice} inPersonCourseTitle={inPersonCourseTitle} inPersonCity={inPersonCity} inPersonImageSrc={inPersonImageSrc} inPersonLink={inPersonLink} inPersonDate={inPersonDate} inPersonState={inPersonState} themeColor={themeColor} />

                </div>
              </div> */}
            
          </div>



        </div>
        <div className="md:pt-[72px]">

          {/* <Suspense fallback={<div className="w-full flex flex-col ">
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
          </div>}>
            <EducatorSlugMyTips
              params={params}
              user={user}
              themeColor={themeColor} />
          </Suspense> */}


          <Suspense fallback={<div className="w-full flex flex-col ">
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
          </div>}>
            <EducatorSlugMyCoursesDesktop
              params={params}
              user={user}
              themeColor={themeColor} />
          </Suspense>


          {/* <Testimonials testimonials={educatorData.educatorMetaData.educatortestimonials || []} /> */}

</div>
       
      </div>

    </main>
  );
}

// add dynamic title and description to each educator slug page
export async function generateMetadata(
  { params }: { params: { slug: string } },
  parent: ResolvingMetadata
): Promise<Metadata> {

  const metadata = await getEducatorMetadata(params);

  return {
    title: metadata.title + " (" + metadata.educatorMetaData.instahandle + ")",
    description: metadata.educatorMetaData.shortBio
  }
}