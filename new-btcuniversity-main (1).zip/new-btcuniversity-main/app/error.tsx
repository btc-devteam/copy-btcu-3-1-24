"use client"; // Error components must be Client Components

// import {
//   Alert,
//   AlertDescription,
//   AlertTitle,
// } from "@/components/shared/ui/Alert";
// import { AlertCircle } from "lucide-react"; Mihai commented out as it doesn't seem to be used
import { notFound } from "next/navigation";
import { useEffect } from "react";

export default function Error({
  error,
  reset,
}: {
  error: Error;
  reset: () => void;
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error);
  }, [error]);

  return (
    <div>
      {error?.message === "NEXT_NOT_FOUND" ? (
        notFound()
      ) : (
        <>
          {error?.message ?
            'Error, please refresh the page.'
            : "Somthing went wrong"}

          <button
            className="mt-4 text-sm font-semibold text-white bg-blue-500 rounded-md px-3 py-1.5 hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75"
            onClick={
              // Attempt to recover by trying to re-render the segment
              () => reset()
            }
          >
            Try again
          </button>
        </>
      )}
    </div>
  );
}