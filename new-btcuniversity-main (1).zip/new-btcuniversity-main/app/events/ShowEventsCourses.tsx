// import React from 'react';
// import { getbtcEventsCourses } from './helper';
// import { Section, createCourseCards } from '../business/helper';

// const ShowEventsCourses: React.FC = async () => {

//     const showEventsCoursesPromise = getShowEventsCourses();
//     const showEventsCourses = await showEventsCoursesPromise;
//     const showEventsCards = createCourseCards(showEventsCourses);

//     return (
//         <div id="btc-show">
//           <Section title="BTC SHOW" cards={showEventsCards} />
//         </div>
//     );
// }

// export default ShowEventsCourses;