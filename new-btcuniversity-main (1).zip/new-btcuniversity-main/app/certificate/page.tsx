'use client'
import { PDF } from '@/app/certificate/PDFView';
import ReactPDF from '@react-pdf/renderer';
import dynamic from 'next/dynamic';
import React from 'react';
const PDFView = dynamic(() => import('@/app/certificate/PDFView'), {
    ssr: false
})

const page = () => {

    const certificateInfo = {
        courseNmae: "Fall's Hottest Haircouts Fall's Hottest Haircouts",
        CLO: "<p>Justin's viral butterfly layer cutting technique</p>",
        Instructors: [{
            id: 0,
            img: 'http://localhost:3000/_next/image?url=http%3A%2F%2Flocalhost%3A3000%2Fimages%2Fuploads%2F2023%2F07%2FAshlee-Norman-300x300-1.jpg&w=1920&q=75',
            handle: '@chrisones_hairs',
            name: 'Chris Jones'
        },
        {
            id: 1,
            img: 'http://localhost:3000/_next/image?url=http%3A%2F%2Flocalhost%3A3000%2Fimages%2Fuploads%2F2023%2F07%2FDaniel-Mora-300x300-1.jpg&w=1920&q=75',
            handle: '@rachelwstylist',
            name: 'Rachel Williams'
        },
        {
            id: 2,
            img: 'http://localhost:3000/_next/image?url=http%3A%2F%2Flocalhost%3A3000%2Fimages%2Fuploads%2F2023%2F07%2FDanilo-Bozic-300x300-1.jpg&w=1920&q=75',
            handle: ' @styled-by-carolynn',
            name: 'Carolynn Judds'
        },
        {
            id: 3,
            img: 'http://localhost:3000/_next/image?url=http%3A%2F%2Flocalhost%3A3000%2Fimages%2Fuploads%2F2023%2F07%2FCarly-Zanoni-300x300-1.jpg&w=1920&q=75',
            handle: '@brianacisneros',
            name: 'Briana Cisnesos'
        }
        ],
        std: {
            firstName: 'Hamzah',
            lastName: 'Syed',
            DateOfCompletion: "Dec 19/23",
        }
    }

    return (
        <div>
            <h1>Next.js PDF Viewer</h1>
            <PDFView info={certificateInfo} />
            {/* <PDF />  */}
        </div>
    )
}

export default page
