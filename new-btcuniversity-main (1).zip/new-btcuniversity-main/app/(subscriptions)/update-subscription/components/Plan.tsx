import { FC } from "react";
import CouponForm from "./CouponForm";
import Link from "next/link";
import { getRequestCookie } from "@/components/auth/getAuthCookie";
import { cookies } from "next/headers";
import {
  getCustomerSubs,
  getStripeSubs,
} from "@/features/stripe/subscriptions";
import { getCurrentStripeSub } from "../helper";
import Stripe from "stripe";
import B1Text from "@/components/text/B1Text";
import { formatDateToDisplay } from "@/utils/formatDate";
import PlanClientComponent from "./PlanClientComponent";
import { checkSubIsValidSubscriptionObject } from "@/utils/subValidation";
type ButtonValue = string | null;
interface MyComponentProps {
  className?: string;
  searchParams?: { [key: string]: string | string[] | undefined };
}
const Plan: FC<MyComponentProps> = async ({
  searchParams,
}: MyComponentProps) => {
  const searchVal = searchParams?.q;
  const searchValStep = searchParams?.step;

  const user = await getRequestCookie(cookies());

  let subsDataProm = getStripeSubs();
  let currentCustomerSubscriptionProm = getCustomerSubs(
    user?.userData?.databaseId!
  );

  const [subsData, currentCustomerSubscription] = await Promise.all([
    subsDataProm,
    currentCustomerSubscriptionProm,
  ]);

  

  if (!subsData || !currentCustomerSubscription) {
    throw "Somthing went wrong";
  }

  const currentStripSub = getCurrentStripeSub(
    subsData.data,
    currentCustomerSubscription
  );

  const price = currentStripSub.default_price as Stripe.Price;

  const isGift = currentCustomerSubscription.subscriptionMetadata
    .tigiftrecipientemail
    ? true
    : false;
  return (
    searchVal == "update-subscription" &&
    searchValStep == null && (
      <div className="w-full my-8">
        <h2 className="text-themecolor-500 font-semibold">Your Plan</h2>
        <div className="w-full flex flex-col bg-themecolor-50 rounded px-4 py-2 mt-4 text-16 text-themecolor-500">
          <div className="flex justify-between items-center p-4 border-b border-secondarythemecolor">
            <B1Text text="Member since" />
            <B1Text
              className="!font-semibold"
              text={formatDateToDisplay(
                currentCustomerSubscription.subscriptionMetadata
                  .subscriptionstartson
              )}
            />
          </div>
          <div className="flex justify-between items-center p-4 border-b border-secondarythemecolor">
            <B1Text text={currentStripSub.name} />
            <B1Text
              className="!font-semibold"
              text={`$${(price.unit_amount! / 100).toFixed(2)}/${
                price.recurring?.interval
              }`}
            />
          </div>
          {!currentCustomerSubscription.subscriptionMetadata
            .subscriptioncanceledon && (
            <div className="flex justify-between items-center p-4 border-secondarythemecolor">
              <B1Text text="Next Billing Date" />
              <B1Text
                className="!font-semibold"
                text={`${formatDateToDisplay(
                  currentCustomerSubscription.subscriptionMetadata
                    .subscriptionrenewson
                )}`}
              />
            </div>
          )}
          {currentCustomerSubscription.subscriptionMetadata
            .subscriptioncanceledon && (
            <div className="flex justify-between items-center p-4">
              <B1Text text="Cancellation Date" />
              <B1Text
                className="!font-semibold"
                text={`${formatDateToDisplay(
                  currentCustomerSubscription.subscriptionMetadata
                    .subscriptioncanceledon
                )}`}
              />
            </div>
          )}
        </div>
        <p className="text-16 text-gray-400 mt-5">
          Subscription fee are billed on the same data each month and may take a
          few days after the billing date to process.
        </p>
        <PlanClientComponent
          defaultValue={(price.unit_amount! / 100).toFixed(2)}
          currentWpSub={currentCustomerSubscription}
          cusId={user?.stripe.cus_id!}
          subs={subsData.data}
          currentStripSub={currentStripSub}
        />
        </div>
    )
  );
};

export default Plan;
