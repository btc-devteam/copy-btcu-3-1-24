"use client";

import React, { FC, useState, useTransition } from "react";
// Utils
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { cn } from "@/utils/shadcn";
import { scheduleSub } from "@/lib/services/actions/scheduleSubscription";
import { ICurrentUserSub } from "@/features/stripe/subscriptions";

// Components
import B1Text from "@/components/text/B1Text";
import SH2Text from "@/components/text/SH2Text";
import Completed from "@/components/icons/Completed";
import { Button } from "@/components/ui/Button";
import Link from "next/link";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/Dialog";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/Select";
import { toast } from "react-hot-toast";
import Stripe from "stripe";
import { useRouter } from "next/navigation";
import CouponForm from "./CouponForm";
import { checkCouponCode } from "@/lib/services/actions/checkCoupon";
/**
 * Props interface for the YourPlan component.
 */
interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  subs: Stripe.Product[]; // Array of Stripe products
  currentStripSub: Stripe.Product; // Currently selected Stripe product
  cusId: string; // Customer ID
  currentWpSub: ICurrentUserSub; // Current user's subscription details
  defaultValue?: string; //Default value of selected plan
}

export const FormSchema = z.object({
  plan: z.string({
    required_error: "Please select a plan",
  }),
});

const PlanClientComponent: FC<IProps> = ({
  currentStripSub,
  subs,
  currentWpSub,
  defaultValue,
  cusId,
}) => {
  const [pending, startTransition] = useTransition();
  const { refresh } = useRouter();
  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      plan: currentStripSub.id,
    },
  });

  /**
   * Handles the form submission.
   *
   * @param data - The form data.
   */
  function onSubmit(data: string) {
    const selectedStripeSub = subs.find((item) => item.id === data);
    const selectSubWpId = selectedStripeSub?.metadata?.["wp-id"];
    // setShowConfirmation(true);

    const currentSubPriceData = currentStripSub.default_price as Stripe.Price;
    if (data === currentStripSub.id) {
      return;
    } else {
      startTransition(async () => {
        await scheduleSub(selectSubWpId!, {
          priceData: selectedStripeSub?.default_price as Stripe.Price,
          currentWpSub: currentWpSub,
          coupon
        })
          .then(() => {
            refresh();
            setShowConfirmationPopup(false);
            refresh();
            toast.success("Your plan has been updated!");
            setCoupon(null);
          })
          .catch((err) => {
            toast.error(err.toString());
            form.setValue("plan", currentStripSub.id);
          });
      });
    }
  }

  const [dropdownEnabled, setDropdownEnabled] = useState(false); // State to track if the dropdown is enabled

  const handleButtonClick = (value: string) => {
    setSelectedValue(value);
    setDropdownEnabled(true);
  };
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showConfirmationPopup, setShowConfirmationPopup] = useState(false);

  const handlePlanChangeClick = () => {
    setDropdownEnabled(true); // Enable the dropdown when "Change Plan" is clicked
  };

  const [selectedValue, setSelectedValue] = useState(currentStripSub.id);
  const couponState = useState<string | null>(null);
  const [coupon, setCoupon] = couponState;
  return (
    <>
      <div className=" max-w-xl mt-8 flex flex-col">
        <h2 className="text-themecolor-500 font-semibold">Change Plan</h2>
        <div className="flex flex-wrap gap-3 py-4">
          {subs.map((sub, i) => {
            const price = sub.default_price as Stripe.Price;
            const count = price.recurring?.interval_count!;
            return (
              <button
                key={sub.id}
                disabled={currentStripSub.id === sub.id}
                className={`px-6 py-2 rounded-full text-14 ${selectedValue === `${sub.id}`
                  ? "bg-themecolor-500 text-white"
                  : "bg-white text-gray-400 border-[1px] border-gray-300"
                  }
                ${currentStripSub.id === sub.id && "cursor-not-allowed"}
                `}
                onClick={() => handleButtonClick(sub.id)}
              >
                ${(price.unit_amount! / 100).toFixed(2)}/
                {count > 1 ? `${price.recurring?.interval_count} ` : ""}
                {price.recurring?.interval}
              </button>
            );
          })}
        </div>
        {showConfirmation && (
          <p className="flex flex-row justify-center pt-4">
            <span className="mr-2">
              <Completed fill={"black"} />
            </span>
            <B1Text text="Your plan has been updated!" />
          </p>
        )}
        <div className="mt-5">
          <CouponForm couponState={couponState}  />
        </div>
        <div className="pt-8 pb-3">
          <div className="flex flex-col">
            <Dialog
              open={showConfirmationPopup}
              onOpenChange={setShowConfirmationPopup}
            >
              <DialogTrigger asChild>
                <Button
                  type="button"
                  className="mx-auto"
                  isLoading={pending}
                  disabled={
                    !dropdownEnabled ||
                    selectedValue === defaultValue ||
                    pending
                  }
                  variant="secondary"
                >
                  Update
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Update Subscription</DialogTitle>
                  <DialogDescription className="mt-3 whitespace-pre-line">
                    {` You are purchasing a ${subs.find((s) => s.id === selectedValue)?.name
                      } subscription.\n \n Please be aware that it will become in effect and you will get charged on the day your current subscription ends. However, your content access level permissions will change immediately`}
                    .
                  </DialogDescription>
                </DialogHeader>

                <DialogFooter>
                  <Button
                    isLoading={pending}
                    disabled={
                      !dropdownEnabled ||
                      selectedValue === defaultValue ||
                      pending
                    }
                    onClick={() => onSubmit(selectedValue!)}
                  >
                    Save changes
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <div className="flex justify-center pt-5 pb-3">
            <Button type="button">
              <Link href="/cancel">Cancel Plan</Link>
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default PlanClientComponent;
