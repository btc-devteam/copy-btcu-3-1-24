import React from 'react';
import SH1Text from './text/SH1Text';
import Image from 'next/image';

interface CategoryHeroProps {
  heroTitle: string;
  mobileImage: string;
  desktopImage: string;
  // description: string;
  // heroVideo: string;
}


const CategoryHero: React.FC<CategoryHeroProps> = ({
  // heroVideo,  description,
  mobileImage, desktopImage, heroTitle, }) => {

  console.log("desktopImage in CategoryHero is: ", desktopImage);

  return (
    <div>
      {(desktopImage !== "" || mobileImage !== "") && (
        <div>
          <div className=' bg-[#ADA59C]'>
         

          <div className='md:container md:mx-auto'>
            
          {/* <Herotext text={heroTitle} /> */}
          {/* {heroTitle !== "" && (
          <SH1Text text={description} />
          )} */}

          {/* Mobile */}
          {mobileImage !== "" && (
          <div className='md:hidden '>
                <Image
                  src={mobileImage}
                  alt={heroTitle}
                  width="10000"  // Set width to 100% to take up full width
                  height="10000" // Set height to auto to maintain aspect ratio
                  className="object-cover"
                  style={{ maxHeight: '100%' }}
                />
          </div>
          )}


          {/* Desktop */}
          {desktopImage !== "" && (
            <div className='hidden md:block'>
              <Image
                src={desktopImage}
                alt={heroTitle}
                width="10000"  // Set width to 100% to take up full width
                height="10000" // Set height to auto to maintain aspect ratio
                className="object-cover"
                style={{ maxHeight: '100%' }}
              />
            </div>
          )}

          <div className='flex justify-center '>

          </div>

       
        </div>
          </div>
          <div className='space-between-categories' />

        </div>
      )}
    </div>
  );
}

export default CategoryHero;





