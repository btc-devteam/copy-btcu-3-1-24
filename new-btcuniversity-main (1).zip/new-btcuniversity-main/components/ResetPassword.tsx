// import React, { useState } from 'react';
// import ActionButton from './buttons/ActionButton';
// import BackWordWithChevron from './buttons/BackWithOnClick';
// import SH2Text from './text/SH2Text';
// import H1Text from './text/H1Text';
// import SH1Text from './text/SH1Text';
// import { Button } from './ui/Button';
// import BackWithOnClick from './buttons/BackWithOnClick';

// const ResetPassword = () => {
//   const [showResetPassword, setShowResetPassword] = useState(true);

//   const handleCloseClick = () => {
//     setShowResetPassword(false);
//   };

//   return (
//     <>
    
//       {showResetPassword && (
//         <div className="fixed top-0 left-0 w-full h-full pt-20 bg-black/25 overflow-y-auto">
//           <div className='flex w-full flex-col justify-center bg-white p-5'>
//             <div className='flex w-full flex-col justify-center'>

//             <BackWithOnClick onClick={handleCloseClick} />

//             <div className='pt-2'>
//             <SH1Text text='Reset Password' />
//             <SH1Text text='waiting to confirm with miahi, but to reset actually may be a email so we wont even need this component' />
//               </div>
           
//               <form method="post" className='flex w-full flex-col' id='reset-password'>

//                 <fieldset className='flex w-full flex-col justify-center'>

//                   <label htmlFor="profile-current-password" className='invisible'>Current Password</label>
//                   <input
//                     id="profile-current-password"
//                     type="password"
//                     name="currentPassword"
//                     defaultValue=''
//                     autoComplete=""
//                     placeholder='Current Password'
//                     className='appearance-none h-14 p-2.5 border-solid border border-black font-sans text-sm  placeholder:text-themeColor/50'
//                   />
//                   <label htmlFor="profile-new-password" className='invisible'>New Password</label>
//                   <input
//                     id="profile-new-password"
//                     type="password"
//                     name="newPassword"
//                     defaultValue=''
//                     autoComplete=""
//                     placeholder='New Password'
//                     className='appearance-none h-14 p-2.5 border-solid border border-black font-sans text-sm  placeholder:text-themeColor/50'
//                   />
//                   <label htmlFor="profile-new-password-confirm" className='invisible'>Current Password Confirm</label>
//                   <input
//                     id="profile-new-password-confirm"
//                     type="password"
//                     name="currentPasswordConfirm"
//                     defaultValue=''
//                     autoComplete=""
//                     placeholder='Curent Password Confirm'
//                     className='appearance-none h-14 p-2.5 border-solid border border-black font-sans text-sm  placeholder:text-themeColor/50'
//                   />
// <div className='p-2'>
// <p className="error-message flex justify-center text-red">Error: Please enter correct password</p>

// </div>

//                   <div className='flex justify-center'>
               

// <Button variant="secondary" >Submit</Button>

//                   </div>
//                 </fieldset>
//               </form>
//             </div>
//           </div>
//         </div>
//       )}
//     </>
//   );
// }

// export default ResetPassword;

// // to do: again, this doesn't actually do anything. 