"use client"
import React, { useEffect, useState } from 'react';
import Image from 'next/image';

interface EducatorHeadShotProps {
  imageUrl: string;
}

const EducatorHeadShot: React.FC<EducatorHeadShotProps> = ({ imageUrl }) => {
  const [screenWidth, setScreenWidth] = useState(0);

  useEffect(() => {
    // Check if we are on the client side before accessing the window object.
    if (typeof window !== 'undefined') {
      setScreenWidth(window.innerWidth);
    }

    // Add an event listener to update the screenWidth when the window is resized
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const circleSize = Math.min(screenWidth, 500); // Set the maximum circle size to 500px or the screen width, whichever is smaller

  return (
    <div
      className="overflow-hidden"
      style={{
        width: '100%',
        paddingBottom: '100%', // Maintain a square aspect ratio (1:1)
        position: 'relative',
      }}
    >
      <div
        className='rounded-none '
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          // borderRadius: '50%',
          overflow: 'hidden',
        }}
      >
        <Image
          src={imageUrl}
          alt="Educator Image"
          layout="fill"
          objectFit="cover"
        />
      </div>
    </div>
  );
};

export default EducatorHeadShot;


    // <div className='' style={{ minWidth: '100px', minHeight: '100px', flexShrink: 0 }}>
    // <div className="overflow-hidden">
    //   <Image
    //     src={imageUrl}
    //     alt="Educator Headshot"
    //     width={imageWidth}
    //     height={imageHeight}
    //     className="relative z-1"
    //   />
    // </div>
    // </div>

 






    // <div
    //   className="w-full h-full rounded-full overflow-hidden"
    //   style={{ aspectRatio: '1 / 1', position: 'relative' }}
    // >
    //   <div
    //     style={{
    //       position: 'absolute',
    //       top: 0,
    //       left: 0,
    //       width: '100%',
    //       height: '100%',
    //       borderRadius: '50%',
    //       overflow: 'hidden',
    //     }}
    //   >
    //     <Image
    //       src={imageUrl}
    //       alt="Educator Headshot"
    //       layout="fill"
    //       objectFit="cover"
    //     />
    //   </div>
    // </div>