import { Page, Text, View, Document, StyleSheet } from '@react-pdf/renderer';
import OneEducatorCert from './OneEducatorCert';

const styles = StyleSheet.create({
  page: {
    flexDirection: 'row',
    backgroundColor: '#E4E4E4'
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1
  }
});

export const MyPDFDocument = () => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.section}>
       <Text>
       <OneEducatorCert />
        </Text>
      </View>
   
    </Page>
  </Document>
);


// error, this is not transforming to a pdf. need to do more research
