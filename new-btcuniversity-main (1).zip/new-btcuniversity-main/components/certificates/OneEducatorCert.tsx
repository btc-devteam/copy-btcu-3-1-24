"use client"
import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import CertClassTitle from '../text/CertClassTitle';
import CertDetails from '../text/CertDetails';
import { Page, Text, View, Document, StyleSheet, PDFDownloadLink } from '@react-pdf/renderer';
import { MyPDFDocument } from './MyPDFDocument';
import FullBTCULogoSVG from '../icons/FullBTCULogoSVG';

const OneEducatorCert = () => {
  const [showPDF, setShowPDF] = useState(false);

  const generatePDF = () => {
    setShowPDF(true);
  };

  return (
    <Page >
    <div id="pdf-content" className='border-2 border-black p-4'>
 {/* <button onClick={handlePrintPDF}> */}
      <div className='text-center'>
        <div className='flex justify-center'>
          {/* <div className='-mt-4 -mb-4'>
            <Behindthechair />
          </div> */}
        </div>
        <div className='-mt-4 flex justify-center'>
          <FullBTCULogoSVG height={'100'}  />
        </div>
        <p className='-mt-4 text-black font-playfair font-semibold text-6xl tracking-wider leading-normal'>
          CERTIFICATE OF COMPLETION
        </p>
      </div>
      <div className='p-4'>
        <div className='flex flex-col md:flex-row'>
          <div className='w-full md:w-1/3 md:pr-4 mb-4 md:mb-0 p-3'>
            <div className='flex justify-center p-3'>
              <Link href="/#">
                <div className="w-60 h-60 rounded-full overflow-hidden">
                  <Image
                    src={"https://btcu2023react1.wpengine.com/wp-content/uploads/2023/03/alisha-jared-headshot-scaled.jpg"}
                    alt="educator"
                    width={380}
                    height={380}
                  />
                </div>
              </Link>
            </div>
            <div className=''>
              <CertDetails text='In this exclusive BTCU online class, @educatorshandle, covered:' />
        
            </div>
            <div className='text-black font-oswald font-bold text-xl leading-normal'>
              Triangle Sectioning: Why you should use it and how to determine the size
              Application: Learn the difference between point work and dry brushing
              Saturation: What are the 3 zones of saturation and why they matter
            </div>
            <div className='flex justify-center p-1'>
              <Image
                src={"https://btcu2023react1.wpengine.com/wp-content/uploads/2023/09/download.jpeg"}
                alt="brand logo"
                width={180}
                height={180}
              />
            </div>
          </div>
          <div className='w-full md:w-2/3 md:pl-4'>
            <div className='mb-4'>
              <CertClassTitle text="@handle" />
              <CertClassTitle text="@Class Title" />
            </div>
            <div className='p-4'>

            
            <div className='font-cursive text-center text-6xl leading-normal pt-2 pb-2'>
              <div className='relative inline-block w-full'>
                Mary Rector
                <div className='absolute bottom-0 left-0 w-full h-px bg-black'></div>
              </div>
            </div>
            <div className='flex pt-1 pb-1'>

            
           Educator Name
          
            @educatorhandle
            </div>
            <div className='font-cursive text-center text-6xl leading-normal pt-3'>
              <div className='relative inline-block w-full'>
                Briana Sanazzaro
                <div className='absolute bottom-0 left-0 w-full h-px bg-black'></div>
              </div>
            </div>
            <div className='flex pt-1 pb-1'>
     Has Successfully completed:
            </div>
            <div className='flex pt-1 pb-1'>
         Class Title
            </div>
          </div>
          </div>
        </div>
      </div>
   
      <button onClick={generatePDF}>Generate PDF</button>
      {showPDF && (
        <PDFDownloadLink document={<MyPDFDocument />} fileName="myfile.pdf">
          {({ blob, url, loading, error }) => (loading ? 'Loading document...' : 'Download now')}
        </PDFDownloadLink>
      )}
    </div>
    </Page>
  );
};



export default OneEducatorCert;


// to do: pull in the following items dynamically: educator name and headshot as well as handle. also customer name. and class title and class what you will learn description. 
// error, this is not transforming to a pdf. need to do more research


