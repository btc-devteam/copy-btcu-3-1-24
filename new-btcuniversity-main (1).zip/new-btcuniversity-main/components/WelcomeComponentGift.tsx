"use client"
import React, { useState, CSSProperties } from 'react';
import CoursePageTitles from './text/CoursePageTitles';
import { Button } from './ui/Button';
import BackButton from './buttons/BackButton';
import SH1Text from './text/SH1Text';
import Link from 'next/link';
import ParagraphText from './text/Paragraph';
import InputTextBold from './text/InputTextBold';
import H3Text from './text/H3Text';
import H4Text from './text/H4Text';
import H5Text from './text/H5Text';
import CourseTitle from './text/CourseTitle';


interface WelcomeComponentGiftProps {
  email: string;
  customerName: string;
}

const WelcomeComponentGift: React.FC<WelcomeComponentGiftProps> = ({ customerName, email }) => {
  const [expanded, setExpanded] = useState(false); // Start with content collapsed


  const toggleExpansion = () => {
    setExpanded(!expanded);
  };




  return (
    <div >



      <H3Text
        text={`Thank you for spreading the gift of growth with BTC University Subscription, ${customerName}!`}
        className="!text-themeColor"
      />

      <div className="relative">
        <div className="!w-full relative pb-[56.25%] h-0 overflow-hidden md:mt-3 xl:mt-0">
          <iframe
            src={`https://player.vimeo.com/video/869250248?autoplay=1`}
            className="!w-full !h-full !absolute !top-0 !left-0 rounded-xl"
          />
        </div>


        <div className='container md:px-0'>



          {/* <div className="max-w-[700px] mx-auto md:justify-center"> */}
          <div>

            <div className="space-under-category-titles" />

          </div>

          <div className=''>

            {/* <div className="text-center">
                
                <p className="text-16 mt-3 text-center">{`Your ultimate destination for unlocking the secrets to outstanding hair cutting skills! We're delighted to have you join our community, and we're excited to help you embark on a journey of creativity, precision, and style.`}</p>
            </div> */}
            <H4Text text={`Your purchase is complete, and you'll soon receive an email to ${email} containing the gift code(s) to share with the lucky recipient(s).`} />





          </div>

          <div>
            <div className="med-space" />
            <div>
              <H5Text text={`Didn't receive an email?`} />



            </div>
            <ParagraphText text=' If email above is correct, check spam!' />

          


            <ParagraphText text='If the wrong email address is shown above, reach out to our customer service team and we will fix it for you!' />


            <div className='text-sm py-1'>


            </div>
          </div>

          <div className="text-themeColor text-sm p-3">
            Contact Us
            <br>
            </br>
            Email: <Link href="mailto:membership@btcuniversity.com">membership@btcuniversity.com</Link>
            <br>
            </br>
            Phone: (800) 760-3010
          </div>



          <H5Text text={`Explore Further:`} />



          <div className='flex'>


            <Link href="/support" className='underline'>
              <ParagraphText text={` Support Page`} className='text-secondarythemecolor' />

            </Link>
            <ParagraphText text={`&nbsp;- Answers to common questions about BTC University.`} />

          </div>

          

          <div className='py-4'>
            <ParagraphText text=' Thank you for choosing BTC University!' />
      </div>
   
         




        </div>
        <div className="space-under-category-titles" />
        {/* </div> */}
      </div>


      <div className='space-between-categories' />
    </div>

  );
};

export default WelcomeComponentGift;
