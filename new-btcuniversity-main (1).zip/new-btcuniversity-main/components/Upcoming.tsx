import React from 'react';
import SH2Text from './text/SH2Text';
import UpcomingCourseCard from './UpcomingCourseCard';
import SH1Text from './text/SH1Text';
import { Course, Educator } from '@/interfaces';
import YouTubeVideoCard from './YouTubeVideoCard';
import H3Text from './text/H3Text';
import YouTubeVideoCardUpcoming from './YouTubeVideoCardUpcoming';
import { is } from 'date-fns/locale';

interface UpcomingProps {
  upcomingCourses: Course[];
  themeColor: string;
  userDataBaseId: string;
}

const Upcoming: React.FC<UpcomingProps> = ({ upcomingCourses, themeColor, userDataBaseId }) => {
  const createUpcomingCourseCards = (courses: Course[]) => courses.map((course: Course) => (
    <div key={course.uri} className='w-full'>
      <YouTubeVideoCardUpcoming
        course={course}
        userDataBaseId={userDataBaseId}
        themeColor={themeColor}
        educators={(course?.courseMetadata?.educators || []).map((educator: Educator) => educator?.educatorMetaData?.instahandle || "")}
      />
    </div>
  ));
  // create the cards for each upcoming course
  const upcomingCards = createUpcomingCourseCards(upcomingCourses);
  if (upcomingCards.length === 0) {
    return null;
  }

  return (

  
    <div>

      
      <div className="flex items-center slider-container">
        <SH1Text text="Upcoming Courses"
          className='text-themeColor'/>
        <div className='space-under-category-titles' />
      </div>
      <div className="md:flex overflow-x-auto space-x-4  md:pl-[6%]">
        {upcomingCards}
      </div>
    </div>
  );
}
export default Upcoming;
