"use client"
import React, { useState } from 'react';
import Image from 'next/image';
import SH1Text from './text/SH1Text';
import RecommendedEducatorIconCard from './RecommendedEducatorIconCard';
import SH2Text from './text/SH2Text';
import ParagraphText from './text/Paragraph';
import TipCard from './TipCard';
import CardHandle from './text/CardHandle';
import { Tip } from '@/interfaces';
import H3Text from './text/H3Text';


interface TipParentProps {
  heroTitle: string;
  tipVideos: Tip[];
  isSubscribed: boolean;
  userDataId: string;
}

const TipParent: React.FC<TipParentProps> = ({ heroTitle, tipVideos, isSubscribed,
  userDataId, }) => {
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const openLightbox = () => {
    setLightboxOpen(true);
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
  };

  return (
    <div >
     
      <div className='container'>
        <SH1Text text={`${heroTitle} Tips of the Week`} className="text-themeColor" />
        <ParagraphText text={` ${heroTitle} tips in less than 60 seconds`} className="text-border" />
      </div>
      <div className="space-under-category-titles" />

      <div className=" slider-container flex space-x-4 overflow-x-auto">
        {tipVideos?.map((tipVideo: Tip, index) => (
          <TipCard key={index}
          tipTitle={tipVideo?.title || ""}
          imageURL={''}
          videoId={+(tipVideo?.tipmetadata?.video || 0)}
          isSubscribed={isSubscribed}
          courseTitle={tipVideo?.tipmetadata?.tipCourse?.title || ""}
          courseslug={tipVideo?.tipmetadata?.tipCourse?.title === "" ? "" : (tipVideo?.tipmetadata?.tipCourse?.slug || "")}
          educatorLink={''} educatorName={''} userDataId={userDataId}  />
        ))}
      </div>

      <div className="space-between-categories" />
    </div>
  );
};

export default TipParent;
