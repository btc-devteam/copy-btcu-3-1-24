"use client"
import React, { useState, useRef, useEffect } from 'react';
import { Share } from 'lucide-react';
import {
    EmailIcon,
    EmailShareButton,
    FacebookIcon,
    FacebookMessengerIcon,
    FacebookMessengerShareButton,
    FacebookShareButton,
    HatenaShareButton,
    InstapaperShareButton,
    LineShareButton,
    LinkedinIcon,
    LinkedinShareButton,
    LivejournalShareButton,
    MailruShareButton,
    OKShareButton,
    PinterestIcon,
    PinterestShareButton,
    PocketShareButton,
    RedditShareButton,
    TelegramShareButton,
    TumblrShareButton,
    TwitterIcon,
    TwitterShareButton,
    ViberShareButton,
    VKShareButton,
    WhatsappIcon,
    WhatsappShareButton,
    WorkplaceShareButton
} from "react-share";
import {
    Dialog,
    DialogClose,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/Dialog"

import { usePathname } from 'next/navigation';
import { DialogCloseButton } from './DialogCloseButton';
// import { Dialog, DialogContent, Input } from '@mui/material';
// import { DialogTrigger } from '@radix-ui/react-dialog';
import { Label } from '@radix-ui/react-label';
import { Button } from './ui/Button';
// import { DialogClose, DialogFooter } from './ui/Dialog';
import { Copy } from 'lucide-react';
import { Input } from './ui/Input';


interface ShareButtonProps {
    shareText: string;
    shareImg: string;
}

const ShareButton: React.FC<ShareButtonProps> = ({ shareText, shareImg }) => {
    const [showPopup, setShowPopup] = useState(false);
    const popupRef = useRef<HTMLDivElement | null>(null);


    const sharingImg = String(shareImg)

    const togglePopup = () => {
        setShowPopup(!showPopup);
    };

    const closePopup = () => {
        setShowPopup(false);
    };

    const pathname = usePathname() || "";
    const fullPageLink = "https://www.btcuniversity.com" + pathname;

    useEffect(() => {
        // Close the popup when the user clicks outside of it
        function handleClickOutside(event: MouseEvent) {
            if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
                closePopup();
            }
        }

        // Add event listener when the popup is open
        if (showPopup) {
            document.addEventListener('mousedown', handleClickOutside);
        } else {
            // Remove event listener when the popup is closed
            document.removeEventListener('mousedown', handleClickOutside);
        }

        // Clean up the event listener when the component unmounts
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [showPopup]);

    const shareLink = (linkShare: string) => {
        navigator.share({ url: linkShare })
    }
    return (
        <div className="px-2 ">

            {/* Mobile */}
            <div className='md:hidden'>
                <button onClick={() => shareLink(fullPageLink)}>
               
                        <div className='flex justify-center items-center  cursor-pointer'>

                            <div className='flex justify-center items-center '>
                                <Share />
                            </div>

                            {/* <div className='flex justify-center py-1'>
                  {isPinned ? 'Saved' : "Save"} 
                  </div> */}

                        </div>

                  






                </button>
            </div>

            <Dialog>
                <DialogTrigger asChild>
                    {/* Desktop */}
                    <div className='hidden md:block relative'>
                        <button onClick={togglePopup} className="relative">
                       
                                <div className='flex justify-center items-center  cursor-pointer'>

                                    <div className='flex justify-center items-center '>
                                        <Share />
                                    </div>

                                    {/* <div className='flex justify-center py-1'>
                  {isPinned ? 'Saved' : "Save"} 
                  </div> */}

                                </div>

                        </button>
                    </div>


                  




                </DialogTrigger>
                <DialogContent className="sm:max-w-max ">
                    <DialogHeader>
                        <DialogTitle>Share</DialogTitle>
                    </DialogHeader>
                    <div className='bg-slate-200 h-[1px] w-full absolute top-14' />
                    <div className="flex items-center gap-x-5 mt-5">
                        <FacebookShareButton className='flex flex-col items-center gap-y-2' url={fullPageLink} quote={shareText}>
                            <div className=' border-[1px] rounded-full p-2'>
                                <FacebookIcon size={22} className='rounded-full' />
                            </div>
                            <p className='text-12'>Facebook</p>
                        </FacebookShareButton>

                        <LinkedinShareButton className='flex flex-col items-center gap-y-2' url={fullPageLink} >
                            <div className=' border-[1px] rounded-full p-2 '>
                                <LinkedinIcon size={22} className='rounded-full' />
                            </div>
                            <p className='text-12'>LinkedIn</p>
                        </LinkedinShareButton>

                        <WhatsappShareButton className='flex flex-col items-center gap-y-2' url={fullPageLink} >
                            <div className=' border-[1px] rounded-full p-2 '>
                                <WhatsappIcon size={22} className='rounded-full' />
                            </div>
                            <p className='text-12'>WhatsApp</p>
                        </WhatsappShareButton>

                        <EmailShareButton className='flex flex-col items-center gap-y-2' url={fullPageLink} >
                            <div className=' border-[1px] rounded-full p-2 '>
                                <EmailIcon size={22} className='rounded-full' />
                            </div>
                            <p className='text-12'>Email</p>
                        </EmailShareButton>

                        <TwitterShareButton className='flex flex-col items-center gap-y-2' url={fullPageLink} title={shareText}>
                            <div className=' border-[1px] rounded-full p-2 '>
                                <TwitterIcon size={22} className='rounded-full' />
                            </div>
                            <p className='text-12'>Twitter</p>
                        </TwitterShareButton>

                        <PinterestShareButton className='flex flex-col items-center gap-y-2' url={fullPageLink} media={sharingImg}>
                            <div className=' border-[1px] rounded-full p-2 '>
                                <PinterestIcon size={22} className='rounded-full' />
                            </div>
                            <p className='text-12'>Pinterest</p>
                        </PinterestShareButton>
                    </div>
                </DialogContent>
            </Dialog>



        </div>
        //             {
        //     showPopup && (
        //         <div className="fixed inset-0 flex items-center justify-center z-50">
        //             <div className="absolute inset-0 bg-gray-900 opacity-50"></div>
        //             <div className="relative z-50 bg-white p-4 rounded-xl shadow-lg" ref={popupRef}>
        //                 <button className="absolute top-2 right-2 p-2 text-gray-500 hover:text-gray-700" onClick={closePopup}>
        //                     <XCircle />


        //                 </button>
        //                 <div className="space-under-category-titles" />
        //                 <SH2Text text='Share' />
        //                 <div className='mt-2 grid grid-cols-3 md:grid-cols-6 gap-x-2 gap-y-5'>
        //                     <FacebookShareButton className='flex flex-col' url={fullPageLink} quote={shareText}>
        //                         <FacebookIcon />
        //                         Facebook
        //                     </FacebookShareButton>

        //                     <LinkedinShareButton className='flex flex-col' url={fullPageLink} >
        //                         <LinkedinIcon />
        //                         LinkedIn
        //                     </LinkedinShareButton>

        //                     <WhatsappShareButton className='flex flex-col' url={fullPageLink} >
        //                         <WhatsappIcon />
        //                         WhatsApp
        //                     </WhatsappShareButton>


        //                     <EmailShareButton className='flex flex-col' url={fullPageLink} >
        //                         <EmailIcon />
        //                         Email
        //                     </EmailShareButton>

        //                     <TwitterShareButton className='flex flex-col' url={fullPageLink} title={shareText}>
        //                         <TwitterIcon /> Twitter
        //                     </TwitterShareButton>

        //                     <PinterestShareButton className='flex flex-col' url={fullPageLink} media={sharingImg}>
        //                         <PinterestIcon />
        //                         Pinterest
        //                     </PinterestShareButton>




        //                 </div>
        //             </div>
        //         </div>
        //     )
        // } * /}
        // </div >
    );
};

export default ShareButton;