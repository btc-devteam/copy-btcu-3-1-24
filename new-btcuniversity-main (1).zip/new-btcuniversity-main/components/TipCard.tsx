"use client"
import React, { useEffect, useState } from 'react';
import CardHandle from './text/CardHandle';
import CardTitle from './text/CardTitle';
import { Landmark } from "lucide-react";
import toast from "react-hot-toast";
import { LockKeyhole } from 'lucide-react';
import Link from 'next/link';
import { XCircle } from 'lucide-react';
import { ChevronRight } from 'lucide-react';
import CourseTitle from './text/CourseTitle';
import EducatorsName from './text/EducatorsName';
import ParagraphText from './text/Paragraph';
import { Button } from './ui/Button';

interface TipCardProps {
  tipTitle: string;
  imageURL: string;
  videoId: number;
  isSubscribed: boolean;
  courseTitle: string;
  courseslug: string;
  educatorLink: string;
  educatorName: string;
  userDataId: string;
}

let imageWidth = 160;

const now = new Date().toISOString();

const TipCard: React.FC<TipCardProps> = ({ tipTitle, educatorLink, educatorName, courseTitle, courseslug, imageURL, videoId, isSubscribed,
  userDataId,
}) => {
  const [screenWidth, setScreenWidth] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setScreenWidth(window.innerWidth);
    }

    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  if (screenWidth < 768) {

    imageWidth = 160;
  } else {

    imageWidth = 270;
  }

  const openLightbox = () => {
    // Only open the lightbox if the user is subscribed
    if (isSubscribed) {
      setLightboxOpen(true);
    }
    else {
      toast.custom((t) => (
      

    <div
  className={`${
    t.visible ? 'animate-enter' : 'animate-leave'
  }   bg-white w-full  border-[1px]  border-border shadow-lg justify-center items-center m-auto  rounded-xl pointer-events-auto   `}
>

            <div className="flex px-4">
              <button
                onClick={() => toast.dismiss(t.id)}
                className="absolute top-2 right-2 flex  text-themeColor"

              >
                <XCircle />
              </button>
            </div>
            <div className=' '>
        
      
     
          <div className="p-4">
            <div className="flex justify-center">
              <div >
           
                <p className="mt-1 uppercase text-[22px] text-themeColor bold flex justify-center">
                  <b>Subscribe to unlock </b>
                </p>
                  <p className="mt-1 text-[18px] uppercase text-themeColor flex justify-center">
                    Available on all paid plans
                  </p>
                {/* <p className="mt-1 uppercase text-[18px] text-secondarythemecolor flex justify-center">
                  just $10/month
                </p> */}
              </div>
            </div>
          </div>
          <div className='flex justify-center pb-4'>
            <div className="flex  border-border">
                  <Link href={'/subscribe'}>

                  <Button className='subscribe-button-click-tip'>
                      SUBSCRIBE
                    </Button>
                  </Link>
            </div>
            {/* <div className="flex  border-border">
              <button
                onClick={() => toast.dismiss(t.id)}
                className="w-full border border-transparent rounded-none rounded-r-lg px-4 flex items-center justify-center text-sm font-medium focus:outline-none"
              >
                <XCircle/>
              </button>
            </div> */}
</div>
          </div>
          </div>
        
      ));
    }
    // datalayer push
    // Pushing data to the dataLayer using type assertion // temporary solution
    (window as any).dataLayer.push({
      event: 'tipAccessed',

      userDataId: userDataId,
      
      tipTitle: tipTitle,
      tipVideoId: videoId,
      
      userWasSubscribedAndCouldViewTip: isSubscribed,
      viewedAt: now
    });



  };

  const closeLightbox = () => {
    setLightboxOpen(false);
  };

  return (
    <div className='tipcard '>
      <div className=' border-[1px] border-border rounded-xl shadow-lg h-full '>
      {/* Image with lightbox functionality */}
      <div className="h-full object-cover">
        <div id="tipcard" style={{ width: `${imageWidth}px`, height: `auto` }}  onClick={openLightbox}>
          
    


            <div className='relative'>
            <div className="!w-full relative pb-[177.78%] h-0 overflow-hidden ">
                <iframe
                  src={`https://player.vimeo.com/video/${videoId}`}
                  className="!w-full !h-full !absolute !top-0 !left-0 rounded-t-xl"
                />
              </div>
            {/* <iframe
              src={`https://player.vimeo.com/video/${videoId}`}
             
           
              style={{ position: 'relative' }}
              frameBorder="0"
              allowFullScreen
              className="rounded-xl"
            ></iframe> */}
            {/* Overlay with "subscribe to view" message */}
            <div className={`absolute inset-0 items-center justify-center ${!isSubscribed ? '' : ''} ${lightboxOpen ? 'hidden' : ''}`}>

              {/* only show lock to unsubscribed users */}
              {!isSubscribed && (
                <div className="flex justify-center items-center h-full">
                  {/* <div className='bg-white w-16 h-8 rounded-xl flex justify-center items-center p-3'>
                    <LockKeyhole />
                  </div> */}



                </div>
              )}

           




            </div>

          </div>

       

      
          <div style={{ width: `${imageWidth}px`, }}>
            <div className='p-2 h-full items-center'>
              <CourseTitle text={tipTitle} />
              
</div>
            {/* <CourseTitle text={tipTitle} /> */}

          </div>
          {educatorLink && (
            <Link href={educatorLink}>
              <div style={{ width: `${imageWidth}px` }}>
                <ParagraphText text={educatorName} />
              </div>
            </Link>
          )}

       
 </div>
        
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <div>


          {lightboxOpen && (
            <div
              className="fixed inset-0 z-50 justify-center items-center bg-black bg-opacity-75"
              onClick={closeLightbox}
            >
                <div className="w-screen h-screen relative bg-black md:bg-transparent">
                  <iframe
                    src={`https://player.vimeo.com/video/${videoId}?autoplay=1`}
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                    }}
                    frameBorder="0"
                    allowFullScreen
                    className="rounded-xl"
                  ></iframe>

                  <div className="bg-black rounded-xl absolute top-0 left-0 m-2 p-2 text-white z-50 px-6 md:px-10">
                    <CardTitle text={tipTitle} className="text-white" />
                    {courseslug !== "" && (
                      <Link href={`/courses/${courseslug}`} className="flex items-center">
                        <CardTitle text={`Course: ${courseTitle}`} className="text-white items-center" />{' '}
                        <ChevronRight fill="" className='items-center'/>
                      </Link>
                    )}
                  </div>

                  <div className="  absolute top-2 right-2 z-50 cursor-pointer">
                    <div className="py-3">
                      <XCircle
                        fill={'white'}
                        
                        onClick={closeLightbox}
                        size={38}
                      />
                    </div>
                  </div>
                </div>

            </div>
          )}



        </div>
      )}
    </div>
     </div >
  );
};

export default TipCard;
