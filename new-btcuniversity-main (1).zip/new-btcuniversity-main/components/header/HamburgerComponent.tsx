// "use client"
// import { useEffect, useState, useTransition } from 'react';
// import Link from 'next/link';
// import Image from 'next/image';
// import SH4Text from '../text/SH4Text';
// import H1Text from '../text/H1Text';
// import SH2Text from '../text/SH2Text';
// import { Menu } from 'lucide-react';
// import ActionButton from '../buttons/ActionButton';

// import { handleLougout } from '@/features/login/logout';
// import { usePathname, useRouter } from 'next/navigation';
// import { UserSession, Course, Educator, EducatorAndTheirCourses } from '@/interfaces';
// import toast, { ToastBar } from 'react-hot-toast';
// import Loader from '../ui/Loader';
// // import Logout from '../icons/Logout';
// import { Button } from '../ui/Button';
// import T1Text from '../text/T1Text';
// import { XCircle, X, ChevronRight, ChevronDown } from 'lucide-react';
// import InputTextBold from '../text/InputTextBold';
// import { User } from 'lucide-react';
// import { IUserProfile } from '@/features/wp/user';
// import { generateWpPageError } from '@/utils/wpErrorHandling';
// import SearchComponent from './SearchComponent';
// import LogoutButton from '@/app/profile/components/Logout';

// // const fullName = 'Full Name' // switched to dynamic below, Briana to use as needed

// interface IProps {
//   userData: UserSession | null
//   userAdditionalData: IUserProfile | null
//   coursesSearch: Course[];
//   educatorsSearch: Educator[];

// }
// function HamburgerComponent({ userData, coursesSearch, educatorsSearch, userAdditionalData }: IProps) {
//   const [isOpen, setIsOpen] = useState(false);
//   const [pending, startTransition] = useTransition()
//   const [loading, setLoading] = useState(false);
//   const loggedIn: boolean = userData?.isLoggedIn ?? false
//   const [isCategoriesExpanded, setIsCategoriesExpanded] = useState(false);
//   const [url, setUrl] = useState<string | null>(userAdditionalData?.user?.avatarUrl || null);
//   const [isLoading, setIsLoading] = useState(false)

//   const fullName = userData?.userData?.name || "";

//   const handleImageChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
//     if (event.target.files && event.target.files.length > 0) {
//       // setSelectedImage(event.target.files[0]);
//       handleUpload(event.target.files[0]);
//     }

//   };

//   const handleUpload = (file: File | null) => {
//     if (file) {
//       setIsLoading(true);
//       const formData = new FormData();
//       formData.append("operations", JSON.stringify({
//         query: `
//                   mutation upload($id:ID!, $avatar:Upload!) {
//                       uploadUserAvatar(
//                           input: {userId: $id, avatar:$avatar}
//                       ) {
//                           avatarUrl
//                       }
//                   }
//               `,
//         variables: {
//           id: Number(userData?.userData?.databaseId),
//           avatar: null // Placeholder for the selected image file
//         }
//       }));
//       formData.append("map", JSON.stringify({ "0": ["variables.avatar"] }));
//       formData.append("0", file);

//       fetch(process.env.NEXT_PUBLIC_WORDPRESS_API_URL!, {
//         method: "POST",
//         body: formData,
//         headers: {
//           "Authorization": `Bearer ${userData?.authToken}`,
//         }
//       })

//         .then(response => response.json())
//         .then(data => {
//           if (data?.errors) {
//             console.log(data?.errors)
//             throw data.errors;
//           }
//           startTransition(() => {
//             setUrl(data.data.uploadUserAvatar?.avatarUrl);
//           })
//           // return data.
//         })
//         .catch(error => {
//           toast.error(generateWpPageError(error).message);
//           console.log(error)
//         })
//         .finally(() => {
//           setIsLoading(false);
//         })
//     }
//   };

//   // Rest of your component...

//   const toggleCategories = () => {
//     setIsCategoriesExpanded(!isCategoriesExpanded);
//   };
//   // Add a useEffect hook to control scrolling
//   // Add a useEffect hook to control scrolling
//   useEffect(() => {
//     if (isOpen) {
//       // Disable scrolling on the body when the menu is open
//       document.body.style.overflow = 'hidden';
//     } else {
//       // Re-enable scrolling on the body when the menu is closed
//       document.body.style.overflow = 'auto';
//     }

//     // Cleanup the style when the component unmounts
//     return () => {
//       document.body.style.overflow = 'auto';
//     };
//   }, [isOpen]);


//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };

//   const handleLinkClick = () => {
//     setIsOpen(false); // Close the menu when a link is clicked
//   };

//   const allCategories = [

//     // 'celeb-stylists',
//     // 'social-media',
//     // 'social-climbing',
//     'haircolor',
//     'haircutting',
//     'styling',
//     'texture',
//     'business',
//     'mens',
//     'hairextensions',
//     'events',
//     // 'masterclasses',
//     // 'languages',
//   ];


//   // Define a type for categoryDisplayNames with an index signature
//   interface CategoryDisplayNames {
//     [key: string]: string;
//   }

//   const categoryDisplayNames: CategoryDisplayNames = {

//     // 'celeb-stylists': 'Celeb Stylists',
//     // 'social-media': 'Social Media',
//     // 'social-climbing': 'Social Climbing',
//     'haircolor': 'Hair Color',
//     'haircutting': 'Hair Cutting',
//     'styling': 'Styling',
//     'texture': 'Texture',
//     'business': 'Business',
//     'mens': "Men's",
//     'hairextensions': 'Hair Extensions',
//     'events': 'Events',
//     // 'masterclasses': 'Master Classes',
//     // 'languages': 'Languages',

//   };
//   const categoryItems = allCategories.map((category) => (

//     <li key={category} className='list-none pl-8'>
//       <Link href={`/${category}`}>
//         <div className='flex items-center '>
//           <div className='w-full py-4 px-4 flex-col '>
//             <InputTextBold text={categoryDisplayNames[category]} />
//           </div>
//           <ChevronRight />
//         </div>

//       </Link>

//     </li>

//   ));


//   const { refresh } = useRouter()

//   return (

//     <div className="relative px-[16px]">
//       {isOpen && (
//         // Dark overlay for the content
//         <div
//           className="fixed inset-0 mt-[50px] bg-black opacity-50 z-2147483647"
//           onClick={toggleMenu}
//         ></div>
//       )}

//       <div className="flex items-center">
//         {/* Hamburger menu */}
//         <div className="flex items-center">
//           <button className="focus:outline-none" onClick={toggleMenu}>
//             {isOpen ? (
//               <X />


//             ) : (
//               <Menu />
//             )}
//           </button>
//         </div>

//         {/* Menu */}

//         {/* below makes it so mobile is full width, desktop is 1/4 page */}

//         <div
//           className={`fixed w-[92%] md:w-[500px] h-full overflow-x-auto top-0 mt-[50px] left-0 bg-white z-50 transition duration-500 ease-in-out transform ${isOpen ? '' : '-translate-x-full overflow-y-auto'
//             }`}
//         >


//           <div className='container'>
//             <div >
//               {loggedIn ? (
//                 <div className='pt-4'>

//                 <div className="flex  border-[1px]  border-border rounded-xl container bg-themecolor-50 text-center">


//                   <div className="items-center justify-center mx-auto py-3">
//                     <Link href={'/profile'} onClick={handleLinkClick} className=''>


//                       <div className="w-full flex flex-col items-center justify-center mx-auto pb-2">
//                         You are logged in as:
//                       </div>





//                       <label
//                         htmlFor="avatar"
//                         className="flex justify-center items-center flex-col w-fit mx-auto cursor-pointer"
//                       >

//                         <input
//                           name="avatar"
//                           type="file"
//                           id="avatar"
//                           hidden
//                           accept="image/png, image/jpeg, image/jpg"
//                           onChange={handleImageChange}
//                         />
//                         <div className="rounded-full w-10 h-10 flex relative justify-center items-center bg-pressedGrey">

//                           {
//                             pending || isLoading ?

//                               <Loader className="h-5 w-5 ml-3" /> :
//                               url ?
//                                 <div className='rounded-full  border-[1px] border-black'>
//                                   <User />
//                                 </div>

//                                 :
//                                 <User />
//                           }
//                         </div>

//                       </label>


//                       <div className="pt-2 flex flex-col items-center justify-center mx-auto">
//                         {`${userData?.userData?.email}`}
//                       </div>
//                     </Link>
//                     </div>
//                   </div>
//                 </div>
//               ) : (
//                 <div className='py-6'>

//                   <Link href="/log-in" className=''>
//                     <Button>Log In</Button>
//                   </Link>
//                 </div>
//               )}
//             </div>
//             {/* Mobile */}
//             <div className='md:hidden py-4 pr-8'>

//               <SearchComponent coursesSearch={coursesSearch} educatorsSearch={educatorsSearch} />
//             </div>



//             <li className='list-none pr-8'>
//               <Link href={`/all-educators`}>
//                 <div className='flex items-center '>
//                   <div className='w-full pt-4 px-4 flex-col '>
//                     <InputTextBold text='Educators' />
//                   </div>
//                   <ChevronRight />
//                 </div>
//                 <div className='grey-line' />

//               </Link>

//             </li>
//             <li className='list-none pr-8'>
//               <div className='flex items-center cursor-pointer' onClick={toggleCategories}>
//                 <div className='w-full px-4 flex-col'>
//                   <InputTextBold text='Explore Courses' />
//                 </div>
//                 {isCategoriesExpanded ? <ChevronDown /> : <ChevronRight />}
//               </div>

//               {isCategoriesExpanded && categoryItems}

//               <div className='grey-line' />
//             </li>
//             <li className='list-none pr-8'>
//               <Link href="/tips">

//                 <div className='flex items-center '>
//                   <div className='w-full  px-4 flex-col '>
//                     <InputTextBold text='Quick Tips' />
//                   </div>
//                   <ChevronRight />
//                 </div>
//                 <div className='grey-line' />

//               </Link>

//             </li>
//             <li className='list-none pr-8'>
//               <Link href="/downloadables">

//                 <div className='flex items-center '>
//                   <div className='w-full  px-4 flex-col '>
//                     <InputTextBold text='Downloadable Resources' />
//                   </div>
//                   <ChevronRight />
//                 </div>
//                 <div className='grey-line' />

//               </Link>

//             </li>

//             <li className='list-none pr-8'>
//               <Link href="/masterclasses">

//                 <div className='flex items-center '>
//                   <div className='w-full  px-4 flex-col '>
//                     <InputTextBold text='Master Classes' />
//                   </div>
//                   <ChevronRight />
//                 </div>
//                 <div className='grey-line' />

//               </Link>

//             </li>
//             <li className='list-none pr-8'>
//               <Link href="/languages">

//                 <div className='flex items-center '>
//                   <div className='w-full  px-4 flex-col '>
//                     <InputTextBold text='Languages' />
//                   </div>
//                   <ChevronRight />
//                 </div>
//                 <div className='grey-line' />

//               </Link>

//             </li>

//             <li className='list-none pr-8'>
//               <Link href="/bulk-subscription">

//                 <div className='flex items-center '>
//                   <div className='w-full  px-4 flex-col '>
//                     <InputTextBold text='Gift A Subscription' />
//                   </div>
//                   <ChevronRight />
//                 </div>
//                 <div className='grey-line' />

//               </Link>

//             </li>

//             <li className='list-none pr-8'>
//               <Link href="/support">

//                 <div className='flex items-center '>
//                   <div className='w-full  px-4 flex-col '>
//                     <InputTextBold text='Support' />
//                   </div>
//                   <ChevronRight />
//                 </div>
//                 <div className='grey-line' />

//               </Link>

//             </li>

//             {/* <div className='space-between-categories' />
//             <div className=''>
//               <H1Text text='My Info' />
//             </div>
//             <div className="space-under-category-titles" />
//             <div className="space-under-category-titles" />
//             <Link href="/profile">
//               <span onClick={handleLinkClick}>
//                 <SH2Text text="My Account" />
//               </span>
//             </Link> */}


//             {/* <div className="space-under-category-titles"/> 
//             <Link href="/checkout">
//               <span onClick={handleLinkClick}>
//                 <SH2Text text="Cart"  />
//               </span>
//             </Link> */}

//             <div className="small-space" />


//             {/* <H1Text text='Resources' />
//             <div className="space-under-category-titles" /> */}

//             <div className='flex'>
//               {/* <Link href="/about" className='pr-2'>
//                 <span onClick={handleLinkClick}>
//                   <Button size="default" variant='outline' className='px-3'> Why BTCU?</Button>

//                 </span>
//               </Link> */}
//               <div className="space-under-category-titles" />

//               {/* <Link href="/support" className='pl-2'>
//                 <span onClick={handleLinkClick}>
//                   <Button size="default" variant='outline' className='px-3' >Help & Support</Button>
//                 </span>
//               </Link> */}
//             </div>

//             <div className="small-space" />

//             <div className='flex flex-col items-start'>

//               <div className="space-under-category-titles" />
//               <span className='cursor-pointer text-white w-full'
//                 onClick={async () => {
//                   if (loggedIn) {
//                     // const loaderId = toast.loading("Logging out!")
//                     startTransition(async () => {
//                       await handleLougout(() => {
//                         refresh();
//                         setIsOpen(false)
//                       })
//                     });
//                     // toast.success("logged out", { id: loaderId })
//                   }
//                   // handleLinkClick();

//                 }}>
//                 {loggedIn ? (
//                   <LogoutButton />


//                   //   <ActionButton
//                   //   link="javascript:void(0)"
//                   //   text="Log Out"
//                   //   textColor="red"
//                   //   icon={<Logout fill='red' />}
//                   //   className='bg-white border-red'

//                   // />

//                 ) : (
//                   <div>

//                   </div>
//                   // <Link href="/log-in">
//                   //   <Button variant="secondary" >Log In</Button>
//                   // </Link>

//                 )}
//               </span>


//               <div className='space-between-categories' />
//               <div className='space-between-categories' />



//             </div>

//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default HamburgerComponent;