"use client";
import React, { Suspense, useState } from "react";
import { usePathname } from "next/navigation";
import ExitFlow from "./ExitFlow";
import { Course } from "@/interfaces";
import BackWithOnClick from "./buttons/BackWithOnClick";
import { CheckCircle, ChevronLeft } from "lucide-react";
import { XCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/Dialog";
import { Skeleton } from "@/components/ui/Skeleton";
import { ScrollArea } from "@/components/ui/ScrollArea";
interface ParentExitFlowProps {
  upcomingCourses: Course[];
  courseName: string;
  educatorHandles: string[];
  image: string;
  customeremail: string;
  certificateimage: string;
  themeColor: string;
  // coursesFromTheSameSeries: Course[]; // make sure current course is removed
  coursesFromTheSameEducator: Course[]; // make sure current course is removed
  relatedCourses: Course[]; // this should already have current course removed
  isExitFlowVisible: boolean; // this will be updated via the callback function below
  hasPreviouslyPostedTestimonial: boolean;
  isSignedIn: boolean;
  courseId: number;
  accessedCourseId: number;
  educatorIds: number[];
  userId: number;
  // firstname: string;
  // lastname: string;
  fullname: string;
  updateExitFlowVisible: (newValue: boolean) => void; // Callback function to update video position
}

const ParentExitFlow: React.FC<ParentExitFlowProps> = ({
  certificateimage,
  customeremail,
  image,
  upcomingCourses,
  courseName,
  educatorHandles,
  themeColor,
  // coursesFromTheSameSeries,
  coursesFromTheSameEducator,
  relatedCourses,
  isExitFlowVisible,
  hasPreviouslyPostedTestimonial,
  isSignedIn,
  courseId,
  accessedCourseId,
  educatorIds,
  userId,
  // firstname,
  // lastname,
  fullname,
  updateExitFlowVisible
}) => {
  const pathname = usePathname();
  // const [isExitFlowVisible, setIsExitFlowVisible] = useState(false);

  const openExitFlow = () => {
    updateExitFlowVisible(true);
  };

  const closeExit = () => {
    updateExitFlowVisible(!isExitFlowVisible);
  };

  const BackButton = ({
    handleExitBack,
    text,
  }: {
    handleExitBack: () => void;
    text?: string;
  }) => <BackWithOnClick onClick={handleExitBack} />;

  const [section, setSection] = useState(1);

  // const handleNext = () => {
  //   setSection(section + 1);
  // };

  const handleExitBack = () => {
    if (section > 1) {
      setSection(section - 1);
    }
  };

  return (
    <div className="flex justify-end">
      {" "}
      {/* Use 'justify-end' to align content to the right */}
      <Dialog key="" open={isExitFlowVisible} onOpenChange={closeExit}>
        {!isExitFlowVisible && (
          <div>
            {/* Content of the parent component when ExitFlow is not visible */}
            <DialogTrigger className="w-fit px-2">
              <div
                className="flex items-center "
                // onClick={openMyInfoModal}
              >
                <button
                  className="bg-themecolor-50 bg-opacity-40 rounded-full w-[45px] h-[45px] flex items-center justify-center"
                  onClick={openExitFlow}
                >
                  <CheckCircle />
                </button>
              </div>
            </DialogTrigger>
          </div>
        )}

        {isExitFlowVisible && (
          <div className=" ">
            {" "}
            {/* Use 'items-end' to align items to the right */}
     
            {/* <div className='w-screen flex justify-end fixed top-16 right-6'>
  <button onClick={closeExitFlow} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
<XCircle />
  </button> 
</div> */}
            <DialogContent className="min-h-fit py-4">
              <DialogHeader >
                <button className={`absolute top-5 left-5 ${section==1&&'hidden'}`} onClick={handleExitBack}>
                  <ChevronLeft size={25} />
                </button>
                <DialogTitle className="px-4 mt-5"></DialogTitle>
                <Suspense
                  fallback={
                    <div className="flex flex-col w-full gap-y-6">
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                      <Skeleton className="h-14" />
                    </div>
                  }
                >
                  <ScrollArea >
                    <ExitFlow
                      upcomingCourses={upcomingCourses}
                      courseName={courseName}
                      educatorHandles={educatorHandles}
                      image={image}
                      certificateimage={certificateimage}
                      customeremail={customeremail}
                      themeColor={themeColor}
                      coursesFromTheSameEducator={coursesFromTheSameEducator}
                      relatedCourses={relatedCourses}
                      section={section}
                      hasPreviouslyPostedTestimonial={hasPreviouslyPostedTestimonial}
                      isSignedIn={isSignedIn} 
                      courseId={courseId} 
                      accessedCourseId={accessedCourseId} 
                      educatorIds={educatorIds} 
                      userId={userId} 
                      // firstname={firstname} 
                      // lastname={lastname} 
                      fullname={fullname} 
                      setSection={setSection} 
                    />
                  </ScrollArea>
                </Suspense>
              </DialogHeader>
            </DialogContent>
          </div>
        )}
      </Dialog>
    </div>
  );
};

export default ParentExitFlow;
