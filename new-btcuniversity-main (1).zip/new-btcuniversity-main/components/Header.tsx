// "use client";
// import React, { useState, useEffect } from "react";
// import Head from "./header/Head";
// import HamburgerComponent from "./header/HamburgerComponent";
// // import ShortBTCULogo from './header/ShortBTCULogo';
// // import FullBTCULogoSVG from './icons/FullBTCULogoSVG';
// import FullBTCULogoSVG from "./icons/FullBTCULogoSVG";
// import { Course, Educator, UserSession } from "@/interfaces";
// import { usePathname } from "next/navigation";
// import { Button } from "./ui/Button";
// import Link from "next/link";
// import SearchComponent from "./header/SearchComponent";
// import { User } from "lucide-react";
// import ButtonText from "./text/ButtonText";
// import { IUserProfile } from "@/features/wp/user";

// // const currentUserData = {
// //   tier: 0, // Replace with the actual user's tier or use your logic to determine it
// // };

// interface IProps {
//   user: UserSession | null;
//   userAdditionalData: IUserProfile | null;
//   userIsCurrentlySubscribed: boolean;
//   themeColor: string;
//   courseSearch: Course[];
//   educatorSearch: Educator[];
// }

// function Header({ user, userAdditionalData, userIsCurrentlySubscribed, courseSearch, educatorSearch }: IProps) {
//   //   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   //  const isDesktop = window.innerWidth > 768;
//   //   const [isSearchOpen, setisSearchOpen] = useState(isDesktop);
//   //   const toggleSearchMenu = isSearchOpen;
//   //   const [prevScrollPos, setPrevScrollPos] = useState(0);
//   //   const [headerVisible, setHeaderVisible] = useState(true);
//   //   const pathname = usePathname();

//   // mihai changed above to below on jan 3
//   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   const [isDesktop, setIsDesktop] = useState(false); // default to false
//   const [isSearchOpen, setIsSearchOpen] = useState(false); // set default based on isDesktop inside useEffect
//   const [prevScrollPos, setPrevScrollPos] = useState(0);
//   const [headerVisible, setHeaderVisible] = useState(true);
//   const pathname = usePathname();

//   const toggleMenu = () => {
//     setIsMenuOpen(!isMenuOpen);
//   };



//   // useEffect(() => {
//   //   const handleScroll = () => {
//   //     const currentScrollPos = window.pageYOffset;
//   //     const isScrollingUp = currentScrollPos < prevScrollPos;

//   //     if (isScrollingUp) {
//   //       setHeaderVisible(true); // Show the header when scrolling up
//   //     } else {
//   //       setHeaderVisible(false); // Hide the header when scrolling down
//   //     }

//   //     setPrevScrollPos(currentScrollPos);
//   //   };

//   //   window.addEventListener("scroll", handleScroll);

//   //   return () => {
//   //     window.removeEventListener("scroll", handleScroll);
//   //   };
//   // }, [prevScrollPos]);

//   useEffect(() => {
//     setIsDesktop(window.innerWidth > 768); // Set isDesktop based on window size
//     setIsSearchOpen(window.innerWidth > 768); // Set isSearchOpen based on window size

//     const handleScroll = () => {
//       const currentScrollPos = window.pageYOffset;
//       const isScrollingUp = currentScrollPos < prevScrollPos;

//       if (isScrollingUp) {
//         setHeaderVisible(true); // Show the header when scrolling up
//       } else {
//         setHeaderVisible(false); // Hide the header when scrolling down
//       }

//       setPrevScrollPos(currentScrollPos);
//     };

//     window.addEventListener("scroll", handleScroll);
//     return () => {
//       window.removeEventListener("scroll", handleScroll);
//     };
//   }, [prevScrollPos]);

//   const headerClasses = `h-[62px] header flex items-center shadow-b-lg bg-white md:mx-auto ${isMenuOpen || headerVisible ? "sticky top-0 bg-white" : ""
//     } ${isMenuOpen || headerVisible ? "z-20" : ""}`;

//   let buttonToRender;

//   if (userIsCurrentlySubscribed === true) {
//     buttonToRender = (
//       <Link href={"/profile"} className="px-2 flex">
//         <div className="rounded-full  border-[1px] border-black">
//           <div >
//             <User />
//           </div>
//         </div>

//         {/* <label
//                 htmlFor="avatar"
//                 className="flex justify-center items-center flex-col w-fit mx-auto cursor-pointer"
//             >
            
//                 <input
//                     name="avatar"
//                     type="file"
//                     id="avatar"
//                     hidden
//                     accept="image/png, image/jpeg, image/jpg"
//                     onChange={handleImageChange}
//                 />
//                 <div className="rounded-full w-36 h-36 flex relative justify-center items-center bg-pressedGrey">

//                     {
//                         pending || isLoading ?

//                             <Loader className="h-5 w-5 ml-3" /> :
//                             url ?
//                              <div className='rounded-full  border-[1px] border-black'>
//      <User />
//       </div>
      
//       :
//                             <User />
//                     }
//                 </div>
                
//             </label> */}
//       </Link>
//     );
//   } else {
//     // If not logged in or with other tiers, show "SUBSCRIBE" button
//     buttonToRender = (
//       <div>
//         {user?.isLoggedIn == null ? (
//           <div className="flex items-center gap-2">

//             {/* Desktop */}
//             <div className="hidden md:flex w-full items-center px-2">
//               <Link href="/log-in">
//                 <ButtonText text="Log In" />
//               </Link>
//             </div>


//             <Button variant={"primary"} size={"default"} className="px-2">
//               <Link href={"/subscribe"} className="px-2">
//                 Subscribe
//               </Link>
//             </Button>
//           </div>
//         ) : (
//           <div className="flex items-center">
//             {/* Desktop */}
//             <div className="hidden md:block px-2">
//               {/* <Link href={"/profile"} className="px-2">
//                 <div className="rounded-full  border-[1px] border-black">
//                   <User />
//                 </div>
//               </Link> */}
//               <Link href={"/profile"} >
//                 <User className="rounded-full  border-[1px] border-black" />
//               </Link>
//             </div>

//             <Button variant={"primary"} size={"default"} className="px-2">
//               <Link href={"/update-subscription"} className="px-2">
//                 Upgrade
//               </Link>
//             </Button>
//           </div>
//         )}
//       </div>
//     );
//   }

//   return (
//     <div className={headerClasses}>
//       <Head />
//       <div className="bg-white md:mx-auto flex items-center py-1">
//         <div className="flex items-center bg-white">
//           <HamburgerComponent key={pathname} userData={user} userAdditionalData={userAdditionalData} coursesSearch={courseSearch} educatorsSearch={educatorSearch} />
//         </div>

//         <div className="flex items-center justify-start">
//           <FullBTCULogoSVG height={"19"} />
//         </div>

//         {/* Desktop */}
//         <div className="hidden md:block">
//           <div className=" rounded-md flex-none">
//             <div className="flex flex-col items-center justify-center h-full cursor-pointer px-2">
//               <SearchComponent coursesSearch={courseSearch} educatorsSearch={educatorSearch} />
//             </div>
//           </div>
//         </div>

       
//       </div>
//       <div className="flex flex-grow justify-end py-[-15px] ml-auto pr-4 ">
//         {buttonToRender}
//       </div>
//     </div>
//   );
// }

// export default Header;
