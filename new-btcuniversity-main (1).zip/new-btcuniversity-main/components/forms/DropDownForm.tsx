import React, { ReactNode, useState } from 'react';
import B1Text from '../text/B1Text';
import Down from '../icons/Down';

interface DropDownFormProps {
  placeholder: string;
  fill?: string;
  borderColor?: string;
  name?: string;
  defaultValue?: string;
  options?: string[]; // Add options prop
}

const DropDownForm = ({
  placeholder,
  fill,
  borderColor,
  name = '',
  defaultValue = '',
  options = [], // Initialize options as an empty array
}: DropDownFormProps) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const handleSelectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newValue = event.target.value;
    setSelectedOption(newValue);
  };

  return (
    <div className="relative">
      <select
        name={name}
        value={selectedOption || defaultValue}
        onChange={handleSelectChange}
        className={`appearance-none  w-full max-w-[395.154px] h-14 p-2.5 border-solid border border-black font-sans text-sm text-themeColor focus:text-themeColor cursor-pointer relative z-10`}
      >
        <option value='' className='text-sm font-sans text-themeColor'>
        {selectedOption || defaultValue || placeholder} 
           <div className="absolute right-2 top-1/2 transform -translate-y-1/2 pointer-events-none">
          <Down fill='black'/>
        </div>
        
        </option>
        {options.map((option, index) => (
          <option
            key={index}
            value={option}
            className='text-sm font-sans text-themeColor'
          >
           
            {option}
          </option>
      
        ))}
      </select>

    </div>
  );
};

export default DropDownForm;


// import React, { ReactNode, useState, useRef, useEffect } from 'react';
// import B1Text from '../text/B1Text';
// import Down from '../icons/Down';

// interface DropDownFormProps {
//   placeholder: string;
//   fill?: string;
//   borderColor?: string;
//   type?: string;
//   name?: string;
//   defaultValue?: string;
//   autoComplete?: string;
//   options?: string[]; // Add options prop
// }

// const DropDownForm = ({
//   placeholder,
//   fill,
//   borderColor,
//   type = 'text',
//   name = '',
//   defaultValue = '',
//   autoComplete = '',
//   options = [], // Initialize options as an empty array
// }: DropDownFormProps) => {
//   const [inputValue, setInputValue] = useState<string>(defaultValue);
//   const [showOptions, setShowOptions] = useState<boolean>(false);
//   const [selectedOption, setSelectedOption] = useState<string | null>(null);

//   const formRef = useRef<HTMLDivElement>(null);
//   const optionsRef = useRef<HTMLUListElement>(null);

//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         formRef.current &&
//         optionsRef.current &&
//         !formRef.current.contains(event.target as Node) &&
//         !optionsRef.current.contains(event.target as Node)
//       ) {
//         setShowOptions(false);
//       }
//     };

//     document.addEventListener('mousedown', handleClickOutside);

//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     const newValue = event.target.value;
//     setInputValue(newValue);
//     setShowOptions(newValue === ''); // Show options when there's no input
//   };

//   const handleOptionClick = (option: string) => {
//     setSelectedOption(option);
//     setInputValue(option);
//     setShowOptions(false);
//   };

//   return (
//     <div className='justify-center items-center relative' ref={formRef}>
//       <form className='p-3 flex appearance-none h-14 border-solid border border-black cursor-pointer'>
//         <div
//           onClick={() => setShowOptions(!showOptions)}
//           className='absolute top-1/2 transform -translate-y-1/2 w-full'
//         >
//           <div className='relative flex items-center'>
//             <input
//               type={type}
//               name={name}
//               value={inputValue}
//               onChange={handleInputChange}
//               autoComplete={autoComplete}
//               className={`border-none outline-none w-full`} // Added pr-12 for right padding
//               placeholder={placeholder}
//             />
//             <div className='absolute right-0 top-0 h-full pr-8 flex items-center pointer-events-none'>
//               <Down fill='black' />
//             </div>
//           </div>
//         </div>
//       </form>
//       {/* Display options as a dropdown if showOptions is true */}
//       {showOptions && (
//         <ul ref={optionsRef} className='border border-black absolute left-0 mt-0'>
//           {options.map((option, index) => (
//             <li key={index} className='p-2 cursor-pointer' onClick={() => handleOptionClick(option)}>
//               {option}
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// };

// export default DropDownForm;

