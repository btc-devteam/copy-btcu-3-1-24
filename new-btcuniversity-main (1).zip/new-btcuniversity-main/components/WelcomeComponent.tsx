"use client"
import React, { useEffect } from 'react';
import CoursePageTitles from './text/CoursePageTitles';
import { Button } from './ui/Button';
import BackButton from './buttons/BackButton';
import SH1Text from './text/SH1Text';
import Link from 'next/link';
import ParagraphText from './text/Paragraph';
import CourseTitle from './text/CourseTitle';
import ParagraphSmall from './text/ParagraphSmall';
import H3Text from './text/H3Text';
import H4Text from './text/H4Text';
import { UserSession } from '@/interfaces';


interface WelcomeComponentProps {
  email: string;
  customerName: string;
  type?: string;
}

const WelcomeComponent: React.FC<WelcomeComponentProps> = ({ customerName, email, type }) => {

  if (type !== "free-subscription" && type !== "single-subscription")  {
    return <></>
  }

  // const [expanded, setExpanded] = useState(false); // Start with content collapsed

  // const toggleExpansion = () => {
  //   setExpanded(!expanded);
  // };

  // above was not used and causing issue in vercel cause it was useState within WelcomeComponent, which is rendered conditionally
  // commented out by mihai on feb 8




  return (
    <div className=''>
      {/* <BackButton /> */}




      <div className="relative">
        <div className='flex justify-center'>
          <SH1Text
            text={`Welcome to BTC University, ${customerName}!`}
            className="!text-themeColor"
          />
        </div>


        <div className="!w-full relative pb-[56.25%] h-0 overflow-hidden md:mt-3 xl:mt-0">
          <iframe
            src={`https://player.vimeo.com/video/869250248?autoplay=1`}
            className="!w-full !h-full !absolute !top-0 !left-0 rounded-xl"
          />
        </div>

        <div className="space-under-category-titles" />
        <div className=''>

          <div className='flex flex-wrap'>



            <span className='font-semibold  text-themeColor text-[14px] md:text-[16px] '>
              Congratulations on joining BTC University—your gateway to &nbsp;
            </span>
            <span className='font-semibold italic text-themeColor text-[14px] md:text-[16px] '>
              unlimited success &nbsp;
            </span>

            <span className='font-semibold text-themeColor text-[14px] md:text-[16px] '>
              behind the chair!
            </span>

          </div>

          <div className="space-under-category-titles" />
          <CourseTitle text={`Action Required: Set Up Your Password Now `} />

          <ParagraphText text={`Before you dive into the wealth of knowledge waiting for you, please take a moment to finish setting up your account by creating a password. Check your ${email} inbox for instructions.`} />

          <div className="space-under-category-titles" />
          <ParagraphText text={`Didn’t receive an email? If the email address above is correct, check spam.`} />



          <div>
            <div className="space-under-category-titles" />
            <div>
              <ParagraphText text={`If the wrong email address is shown above, reach out to our customer service team and we will fix it for you!`} />
            </div>



          </div>

          <div className="text-themeColor text-sm p-3">
            Contact Us
            <br>
            </br>
            Email: <Link href="mailto:membership@btcuniversity.com">membership@btcuniversity.com</Link>
            <br>
            </br>
            Phone: (800) 760-3010
          </div>



          <div>
            <CourseTitle text={`Your Success Journey Starts Here`} />
            <ParagraphText text={`At BTC-U, we understand the importance of continued education in our ever-evolving industry. That’s why our platform is designed to empower you with the tools and techniques you need to level up in your career. Remember, the more you learn, the more you earn!`} />

          </div>

          <div className="space-under-category-titles" />
          <div>
            <CourseTitle text={`What’s New At BTC-U? We Just Got A MAJOR Facelift.* `} />
            <ParagraphText text={`We’ve been working on ourselves. Our biggest goal is to provide YOU with as many resources as possible, to make your business behind the chair easier. Here’s what we’ve added: `} />

          </div>

          <ul className="list-disc list-inside">
            <li className='whitespace-nowrap'>
              <span className='font-semibold text-themeColor text-[14px] md:text-[16px] whitespace-nowrap'>
                Downloadable Library:&nbsp;
              </span>

              <ParagraphText className='pl-6 text-themeColor' text={`Client Letters, Business Guides, Haircutting Headsheets, Social Media Workbooks & more `} />
            </li>


            <li className=''>
              <span className='font-semibold text-themeColor text-[14px] md:text-[16px] whitespace-nowrap'>
                Quick Tips:&nbsp;
              </span>

              <ParagraphText className='pl-6 text-themeColor' text={`Expert hair hacks in 60 seconds or less`} />
            </li>


            <li className='whitespace-normal'>
              <span className='font-semibold text-themeColor text-[14px] md:text-[16px] whitespace-nowrap'>
                Chapter Markers:&nbsp;
              </span>
              <ParagraphText className='pl-6 text-themeColor' text={`Easily jump to or come back to key moments in the class`} />
            </li>


            <li className='list-inside whitespace-normal'>
              <span className='font-semibold text-themeColor text-sm whitespace-nowrap'>
                Course Highlights:&nbsp;
              </span>
              <ParagraphText className='pl-6 text-themeColor' text={`Explore snippets from the class & preview what you’ll learn`} />
            </li>

          </ul>


          <ParagraphSmall text='*Some features only available with the Annual All-Access Plan.' />

          <div className="space-under-category-titles" />
          <CourseTitle text={`Explore Further:`} />



          <div className='flex'>


            <Link href="/support" className='underline'>
              <ParagraphText text={` Support Page`} className='text-secondarythemecolor' />

            </Link>
            <ParagraphText text={`&nbsp;- Answers to common questions about BTC University.`} />

          </div>

          <div className='flex'>


            <Link href="/profile" className='underline'>
              <ParagraphText text={` Profile`} className='text-secondarythemecolor' />

            </Link>
            <ParagraphText text={`&nbsp;- Access your personalized learning hub.`} />

          </div>



        </div>


        <div className="space-under-category-titles" />
        {/* </div> */}
      </div>
      <ParagraphText text={` Welcome to our community! We can’t wait to see your confidence grow behind the chair!`} />

      <div className='space-between-categories' />













      <div className='space-between-categories' />
    </div>

  );
};

export default WelcomeComponent;
